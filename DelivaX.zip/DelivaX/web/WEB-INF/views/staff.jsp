<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.delivax.model.*,java.util.*" %>
<%
  @SuppressWarnings("unchecked")
  List<Order> active=(List<Order>)request.getAttribute("activeOrders");
  @SuppressWarnings("unchecked")
  List<Order> history=(List<Order>)request.getAttribute("historyOrders");
  long pending=request.getAttribute("pending")!=null?(Long)request.getAttribute("pending"):0;
  long preparing=request.getAttribute("preparing")!=null?(Long)request.getAttribute("preparing"):0;
  long ready=request.getAttribute("ready")!=null?(Long)request.getAttribute("ready"):0;
  if(active==null) active=new ArrayList<>();
  if(history==null) history=new ArrayList<>();
  String ctx=request.getContextPath();
%>
<!DOCTYPE html><html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kitchen Dashboard</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:#f1f5f9;color:#1e2d50;font-size:13px}
.page{max-width:480px;margin:0 auto;padding:0 0 20px}
.tb{background:linear-gradient(135deg,#1e3a8a,#1e40af);color:#fff;height:48px;
  padding:0 12px;display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:100;box-shadow:0 2px 10px rgba(30,58,138,.4)}
.tb-logo{font-size:15px;font-weight:900}.tb-logo span{color:#fbbf24}
.tb-btn{background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.26);
  color:#fff;border-radius:14px;padding:4px 11px;font-size:11px;font-weight:700;text-decoration:none}
/* stats */
.stats{display:flex;gap:5px;padding:8px 12px}
.st{flex:1;background:#fff;border-radius:8px;padding:7px 4px;text-align:center;
  border:1px solid #e2e8f0;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.sn{font-size:20px;font-weight:900;line-height:1}
.sn.or{color:#f97316}.sn.bl{color:#1e40af}.sn.gr{color:#16a34a}.sn.pu{color:#7c3aed}
.sl{font-size:8px;font-weight:700;color:#9ca3af;text-transform:uppercase;margin-top:2px}
/* tabs */
.tabs{display:flex;gap:0;margin:6px 12px;background:#e2e8f0;border-radius:8px;padding:2px}
.tab{flex:1;text-align:center;padding:6px;font-size:11px;font-weight:700;cursor:pointer;
  border-radius:6px;color:#6b7a9a;border:none;background:none}
.tab.on{background:#fff;color:#1e40af;box-shadow:0 1px 3px rgba(30,64,175,.12)}
/* order card — very compact */
.oc{background:#fff;border-radius:9px;border-left:3px solid #e2e8f0;
  margin:0 12px 6px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.06)}
.oc.pend{border-left-color:#f97316}.oc.prep{border-left-color:#1e40af}.oc.rdy{border-left-color:#16a34a}
/* header row: #id · name · badge · amount · action · chevron */
.oh{display:flex;align-items:center;gap:5px;padding:7px 10px;
  cursor:pointer;min-height:42px;user-select:none}
.oh:hover{background:#f8faff}
.o-id{font-size:12px;font-weight:900;color:#1e40af;white-space:nowrap;min-width:55px}
.o-name{flex:1;font-size:11px;font-weight:700;color:#374151;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.o-time{font-size:9px;color:#9ca3af;white-space:nowrap}
.o-amt{font-size:12px;font-weight:900;color:#1e40af;white-space:nowrap}
.bdg{display:inline-block;padding:2px 6px;border-radius:8px;font-size:8px;
  font-weight:800;text-transform:uppercase;white-space:nowrap;flex-shrink:0}
.bp{background:#fef9c3;color:#92400e}.bpr{background:#dbeafe;color:#1e40af}
.br{background:#d1fae5;color:#065f46}.bc{background:#fee2e2;color:#991b1b}
.bd{background:#d1fae5;color:#065f46}
/* quick buttons always in header */
.qb{border:none;border-radius:6px;padding:4px 9px;font-size:10px;font-weight:700;
  cursor:pointer;white-space:nowrap;flex-shrink:0}
.qb1{background:#dbeafe;color:#1e40af}.qb2{background:#d1fae5;color:#065f46}.qb3{background:#fee2e2;color:#991b1b}
.chev{font-size:10px;color:#9ca3af;flex-shrink:0;transition:transform .2s}
.chev.op{transform:rotate(180deg)}
/* collapsible body */
.ob{display:none;border-top:1px solid #f1f5f9;padding:7px 10px;font-size:11px}
.ob.on{display:block}
.ir{display:flex;justify-content:space-between;align-items:flex-start;
  padding:3px 0;border-bottom:1px dotted #f1f5f9;font-size:11px}
.ir:last-of-type{border:none}
.ir-l{flex:1;min-width:0}.ir-name{font-weight:700}
.ir-addon{font-size:9px;color:#7c3aed;font-weight:600;margin-top:1px}
.ir-p{font-weight:800;color:#1e40af;white-space:nowrap;margin-left:6px;flex-shrink:0}
.cbox{background:#f8faff;border-radius:6px;padding:6px 8px;margin-top:6px;
  font-size:10px;line-height:1.7;color:#374151}
.o-tot{display:flex;justify-content:space-between;font-weight:900;font-size:12px;
  color:#1e40af;border-top:1.5px solid #e2e8f0;margin-top:6px;padding-top:5px}
/* history */
.hc{background:#fff;border-radius:9px;border-left:3px solid #e2e8f0;
  margin:0 12px 5px;overflow:hidden}
.hh{display:flex;align-items:center;gap:5px;padding:7px 10px;cursor:pointer;min-height:40px}
.hh:hover{background:#f8faff}
.hb{display:none;border-top:1px solid #f1f5f9;padding:7px 10px;font-size:11px}
.hb.on{display:block}
/* inventory */
.inv{background:#fff;border-radius:9px;margin:0 12px 16px;padding:10px 12px;border:1px solid #e2e8f0}
.invr{display:flex;align-items:center;gap:8px;padding:4px 0;
  border-bottom:1px solid #f5f7ff;font-size:11px}
.invr:last-child{border:none}
.invn{min-width:72px;font-weight:700}
.invbar{flex:1;background:#e2e8f0;border-radius:3px;height:5px;overflow:hidden}
.invfill{height:100%;border-radius:3px}
.ok{color:#16a34a;font-weight:700;font-size:10px;white-space:nowrap}
.warn{color:#f59e0b;font-weight:700;font-size:10px;white-space:nowrap}
.empty{text-align:center;padding:30px 16px;color:#9ca3af}
</style>
</head>
<body>
<div class="tb">
  <div>
    <div class="tb-logo">👨‍🍳 Kitchen <span>Dashboard</span></div>
    <div style="font-size:9px;opacity:.7"><%= com.delivax.util.RoleSession.getAttribute(request,"staff","user") %></div>
  </div>
  <a href="<%= ctx %>/logout?role=staff" class="tb-btn">Logout</a>
</div>
<div class="page">
  <div class="stats">
    <div class="st"><div class="sn or"><%= pending %></div><div class="sl">Pending</div></div>
    <div class="st"><div class="sn bl"><%= preparing %></div><div class="sl">Cooking</div></div>
    <div class="st"><div class="sn gr"><%= ready %></div><div class="sl">Ready</div></div>
    <div class="st"><div class="sn pu"><%= history.size() %></div><div class="sl">Done</div></div>
  </div>
  <div class="tabs">
    <button class="tab on" id="ta" onclick="showTab('a')">🔴 Active (<%= active.size() %>)</button>
    <button class="tab" id="th" onclick="showTab('h')">📋 History (<%= history.size() %>)</button>
    <button class="tab" id="ti" onclick="showTab('i')">📦 Stock</button>
  </div>

  <!-- ACTIVE -->
  <div id="pa">
  <% if(active.isEmpty()){ %>
  <div class="empty"><div style="font-size:36px;margin-bottom:6px">🍽️</div><p style="font-size:12px;font-weight:600">No active orders</p></div>
  <% }else{ for(int i=0;i<active.size();i++){ Order o=active.get(i);
     boolean ip="Pending".equals(o.getStatus()), ipr="Preparing".equals(o.getStatus()); %>
  <div class="oc <%= ip?"pend":ipr?"prep":"rdy" %>">
    <div class="oh" onclick="tog('ob<%=i%>','oc<%=i%>')">
      <div class="o-id">#<%= o.getId() %></div>
      <div class="o-name"><%= o.getCustomerName() %></div>
      <div class="o-time"><%= o.getTime() %></div>
      <span class="bdg <%= ip?"bp":ipr?"bpr":"br" %>"><%= o.getStatus() %></span>
      <div class="o-amt">RM<%= String.format("%.2f",o.getTotal()) %></div>
      <% if(ip){ %>
      <form method="post" action="<%= ctx %>/staff" style="display:contents" onclick="event.stopPropagation()">
        <input type="hidden" name="orderId" value="<%= o.getId() %>"><input type="hidden" name="status" value="Preparing">
        <button type="submit" class="qb qb1">🔥</button>
      </form>
      <form method="post" action="<%= ctx %>/staff" style="display:contents" onclick="event.stopPropagation()">
        <input type="hidden" name="orderId" value="<%= o.getId() %>"><input type="hidden" name="status" value="Cancelled">
        <button type="submit" class="qb qb3">✕</button>
      </form>
      <% }else if(ipr){ %>
      <form method="post" action="<%= ctx %>/staff" style="display:contents" onclick="event.stopPropagation()">
        <input type="hidden" name="orderId" value="<%= o.getId() %>"><input type="hidden" name="status" value="Ready">
        <button type="submit" class="qb qb2">✅</button>
      </form>
      <% }else{ %><span style="font-size:9px;color:#16a34a;font-weight:700;white-space:nowrap">🛵 Pickup</span><% } %>
      <span class="chev" id="oc<%=i%>">▼</span>
    </div>
    <div class="ob" id="ob<%=i%>">
      <% if(o.getItems()!=null){ for(CartItem ci:o.getItems()){ %>
      <div class="ir">
        <div class="ir-l">
          <div class="ir-name"><%= ci.getName() %> ×<%= ci.getQty() %></div>
          <% if(ci.getSelectedAddons()!=null&&!ci.getSelectedAddons().isEmpty()){ %>
          <div class="ir-addon">➕ <%= ci.getAddonsDisplay() %></div>
          <% } %>
        </div>
        <div class="ir-p">RM<%= String.format("%.2f",ci.getSubtotal()) %></div>
      </div>
      <% }} %>
      <div class="cbox">📞 <%= o.getCustomerPhone() %> &nbsp;|&nbsp; 🏠 <%= o.getCustomerAddress() %> &nbsp;|&nbsp; 💳 <%= o.getPaymentMethod().toUpperCase() %></div>
      <div class="o-tot"><span>Total</span><span>RM<%= String.format("%.2f",o.getTotal()) %></span></div>
    </div>
  </div>
  <% }} %>
  </div>

  <!-- HISTORY -->
  <div id="ph" style="display:none">
  <% if(history.isEmpty()){ %>
  <div class="empty"><div style="font-size:36px;margin-bottom:6px">📋</div><p style="font-size:12px;font-weight:600">No history yet</p></div>
  <% }else{ for(int i=0;i<history.size();i++){ Order o=history.get(i); %>
  <div class="hc">
    <div class="hh" onclick="tog('hb<%=i%>','hbc<%=i%>')">
      <div class="o-id" style="font-size:11px">#<%= o.getId() %></div>
      <div class="o-name"><%= o.getCustomerName() %> · <span style="color:#9ca3af"><%= o.getTime() %></span></div>
      <span class="bdg <%= "Delivered".equals(o.getStatus())?"bd":"Cancelled".equals(o.getStatus())?"bc":"br" %>"><%= o.getStatus() %></span>
      <div class="o-amt">RM<%= String.format("%.2f",o.getTotal()) %></div>
      <span class="chev" id="hbc<%=i%>">▼</span>
    </div>
    <div class="hb" id="hb<%=i%>">
      <% if(o.getItems()!=null){ for(CartItem ci:o.getItems()){ %>
      <div class="ir">
        <div class="ir-l">
          <div class="ir-name"><%= ci.getName() %> ×<%= ci.getQty() %></div>
          <% if(ci.getSelectedAddons()!=null&&!ci.getSelectedAddons().isEmpty()){ %><div class="ir-addon">➕ <%= ci.getAddonsDisplay() %></div><% } %>
        </div>
        <div class="ir-p">RM<%= String.format("%.2f",ci.getSubtotal()) %></div>
      </div>
      <% }} %>
      <div class="cbox">📞 <%= o.getCustomerPhone() %> &nbsp;|&nbsp; 🏠 <%= o.getCustomerAddress() %></div>
    </div>
  </div>
  <% }} %>
  </div>

  <!-- INVENTORY -->
  <div id="pi" style="display:none">
    <div style="font-size:11px;font-weight:800;color:#374151;padding:6px 12px 5px">📦 Inventory</div>
    <div class="inv">
    <% String[][] inv={{"Chicken","50","83","#16a34a"},{"Lamb","30","50","#f59e0b"},
       {"Rice","100","100","#16a34a"},{"Vegetables","40","67","#f59e0b"},{"Spices","80","80","#16a34a"}};
       for(String[] r:inv){ %>
    <div class="invr">
      <div class="invn"><%= r[0] %></div>
      <div class="invbar"><div class="invfill" style="width:<%= r[2] %>%;background:<%= r[3] %>"></div></div>
      <span class="<%= Integer.parseInt(r[1])<50?"warn":"ok" %>"><%= r[1] %>u</span>
    </div>
    <% } %>
    <div style="background:#fef3c7;border-radius:6px;padding:5px 7px;font-size:10px;color:#92400e;margin-top:7px">⚠️ Lamb running low — restock soon.</div>
    </div>
  </div>
</div>
<script>
function tog(bid,cid){const b=document.getElementById(bid),c=document.getElementById(cid);b.classList.toggle('on');if(c)c.classList.toggle('op');}
function showTab(t){['a','h','i'].forEach(x=>{document.getElementById('p'+x).style.display=x===t?'block':'none';document.getElementById('t'+x).classList.toggle('on',x===t);});}
setTimeout(()=>location.reload(),10000);
</script>
</body></html>
