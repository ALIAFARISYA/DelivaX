<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.delivax.model.*,java.util.*" %>
<%
  Order order=(Order)request.getAttribute("order");
  boolean confirmed=Boolean.TRUE.equals(request.getAttribute("confirmed"));
  java.util.Map<String,Object> custRs=com.delivax.util.RoleSession.get(request,"customer");
  Integer ptsE=custRs!=null&&custRs.get("ptsEarned") instanceof Integer?(Integer)custRs.get("ptsEarned"):null;
  if(ptsE!=null&&custRs!=null) custRs.remove("ptsEarned");
  String ctx=request.getContextPath();
%>
<!DOCTYPE html><html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Track Order</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:#f1f5f9;color:#1e2d50;font-size:13px}
.page{max-width:420px;margin:0 auto;padding:0 0 20px}
.tb{background:linear-gradient(135deg,#1e40af,#2d6cdf);color:#fff;height:48px;
  padding:0 12px;display:flex;align-items:center;justify-content:space-between;
  box-shadow:0 2px 10px rgba(30,64,175,.35)}
.tb-logo{font-size:17px;font-weight:900}.tb-logo span{color:#fbbf24}
.tb-btn{background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.26);
  color:#fff;border-radius:14px;padding:4px 11px;font-size:11px;font-weight:700;text-decoration:none}
/* confirmed banner */
.banner{background:linear-gradient(135deg,#059669,#065f46);color:#fff;
  border-radius:10px;padding:12px;margin:10px 12px 7px;text-align:center}
.banner-ic{font-size:30px;margin-bottom:3px}
.banner h2{font-size:16px;font-weight:900;margin-bottom:2px}
.banner p{font-size:11px;opacity:.85}
.pts-chip{background:rgba(255,255,255,.2);border-radius:8px;padding:3px 9px;
  font-size:10px;font-weight:800;display:inline-block;margin-top:5px}
/* card */
.card{background:#fff;border-radius:10px;border:1px solid #e2e8f0;
  margin:0 12px 7px;padding:10px 12px}
.card-t{font-size:10px;font-weight:800;text-transform:uppercase;
  letter-spacing:.5px;color:#9ca3af;margin-bottom:8px}
/* tracking steps */
.oid-row{text-align:center;margin-bottom:10px}
.oid-num{font-size:15px;font-weight:900}
.oid-dt{font-size:10px;color:#9ca3af;margin-top:2px}
.steps{display:flex;justify-content:space-between;position:relative;margin-bottom:10px}
.steps-line{position:absolute;top:15px;left:14px;right:14px;height:2px;background:#e2e8f0;z-index:0}
.step{display:flex;flex-direction:column;align-items:center;flex:1;position:relative;z-index:1}
.sic{width:30px;height:30px;border-radius:50%;background:#f1f5f9;
  display:flex;align-items:center;justify-content:center;font-size:14px;
  border:2px solid #e2e8f0;margin-bottom:3px}
.step.done .sic{background:#059669;border-color:#059669}
.step.active .sic{background:#1e40af;border-color:#1e40af}
.slbl{font-size:8px;font-weight:700;color:#9ca3af;text-align:center;line-height:1.2}
.step.done .slbl{color:#059669}.step.active .slbl{color:#1e40af}
/* rider */
.ri{display:flex;align-items:center;gap:9px;background:#f8faff;border-radius:8px;padding:9px 10px}
.ri-av{font-size:26px}.ri-name{font-size:12px;font-weight:800}
.ri-sub{font-size:10px;color:#6b7a9a;margin-top:1px}
.eta{text-align:right;flex-shrink:0}
.eta-num{font-size:18px;font-weight:900;color:#1e40af;line-height:1}
.eta-lbl{font-size:8px;color:#9ca3af}
.addr{background:#f8faff;border-radius:7px;padding:7px 9px;margin-top:7px;font-size:11px;line-height:1.7}
/* order items */
.ir{display:flex;justify-content:space-between;align-items:flex-start;
  padding:3px 0;border-bottom:1px dotted #f1f5f9;font-size:12px}
.ir:last-of-type{border:none}
.ir-l{flex:1;min-width:0}.ir-name{font-weight:700}
.ir-addon{font-size:10px;color:#7c3aed;font-weight:600;margin-top:1px}
.ir-p{font-weight:800;color:#1e40af;white-space:nowrap;margin-left:8px;flex-shrink:0}
.ir-tot{display:flex;justify-content:space-between;font-weight:900;font-size:13px;
  color:#1e40af;border-top:1.5px solid #e2e8f0;margin-top:6px;padding-top:6px}
/* payment summary */
.pay-card{background:linear-gradient(135deg,#1e40af,#2563eb);color:#fff;
  border-radius:10px;margin:0 12px 7px;padding:10px 12px}
.pay-card h4{font-size:10px;font-weight:800;opacity:.8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px}
.pg{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.pi{background:rgba(255,255,255,.15);border-radius:7px;padding:7px 9px;text-align:center}
.pi-num{font-size:13px;font-weight:900}
.pi-lbl{font-size:9px;opacity:.75;margin-top:2px}
/* print button */
.print-btn{display:flex;align-items:center;justify-content:center;gap:8px;
  margin:0 12px 7px;padding:12px;
  background:linear-gradient(135deg,#059669,#065f46);
  color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:800;
  cursor:pointer;width:calc(100% - 24px)}
.print-btn:hover{opacity:.92}
/* back */
.back{display:block;text-align:center;color:#1e40af;font-size:12px;font-weight:700;
  padding:11px;border:1.5px solid #1e40af;border-radius:10px;
  text-decoration:none;margin:0 12px}
.refresh{text-align:center;font-size:9px;color:#9ca3af;padding:4px}

/* ═══════════════════════════════════
   PRINT RECEIPT STYLES
   Only visible when printing
═══════════════════════════════════ */
@media print {
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
  body { background: #fff !important; }
  .page { max-width: 100% !important; }
  .tb, .banner, .pay-card, .back, .refresh, .print-btn, .steps-line { display: none !important; }
  .receipt { display: block !important; }
  .no-print { display: none !important; }
  .card { border: 1px solid #ccc !important; margin: 0 0 8px !important; box-shadow: none !important; }
}

/* Receipt — hidden on screen, shows only on print */
.receipt { display: none; }

@media print {
  .receipt-wrap {
    max-width: 380px;
    margin: 0 auto;
    font-family: 'Courier New', monospace;
    color: #000;
  }
  .r-header { text-align: center; padding: 10px 0 8px; border-bottom: 2px dashed #000; margin-bottom: 10px; }
  .r-logo { font-size: 22px; font-weight: 900; letter-spacing: -1px; }
  .r-logo span { color: #000; }
  .r-sub { font-size: 11px; margin-top: 3px; }
  .r-title { font-size: 14px; font-weight: 900; margin: 8px 0 4px; text-transform: uppercase; letter-spacing: 1px; }
  .r-row { display: flex; justify-content: space-between; padding: 3px 0; font-size: 11px; border-bottom: 1px dotted #ccc; }
  .r-row:last-child { border: none; }
  .r-key { color: #444; }
  .r-val { font-weight: 700; text-align: right; }
  .r-divider { border: none; border-top: 2px dashed #000; margin: 8px 0; }
  .r-items-title { font-size: 11px; font-weight: 900; text-transform: uppercase; margin-bottom: 4px; }
  .r-item { display: flex; justify-content: space-between; font-size: 11px; padding: 2px 0; }
  .r-item-addon { font-size: 9px; color: #555; padding-left: 10px; }
  .r-total { display: flex; justify-content: space-between; font-size: 14px; font-weight: 900; padding-top: 6px; border-top: 2px solid #000; margin-top: 6px; }
  .r-footer { text-align: center; font-size: 10px; margin-top: 12px; padding-top: 8px; border-top: 2px dashed #000; line-height: 1.7; }
  .r-status { text-align: center; font-size: 12px; font-weight: 900; margin: 8px 0; padding: 6px; border: 2px solid #000; }
  .r-loyalty { text-align: center; font-size: 11px; margin: 6px 0; padding: 6px; border: 1px dashed #888; }
}
</style>
</head>
<body>
<div class="tb no-print">
  <div><div class="tb-logo">Deliva<span>X</span></div>
    <div style="font-size:9px;opacity:.7">Order Tracking 📍</div></div>
  <a href="<%= ctx %>/menu" class="tb-btn">Menu</a>
</div>

<div class="page">
<% if(order==null){ %>
  <div style="text-align:center;padding:50px 16px;color:#9ca3af">
    <div style="font-size:38px;margin-bottom:8px">📦</div>
    <p style="font-size:12px;font-weight:600">Order not found.</p>
    <a href="<%= ctx %>/menu" style="color:#1e40af;font-weight:700;font-size:12px;display:block;margin-top:12px">← Back to Menu</a>
  </div>
<% }else{
  String[] stats={"Pending","Preparing","Ready","Delivering","Delivered"};
  String[] icons={"📝","🔥","✅","🛵","🏠"};
  int cur=0; for(int i=0;i<stats.length;i++) if(stats[i].equals(order.getStatus())){cur=i;break;}
  String eta="Delivering".equals(order.getStatus())?"10-15":"Ready".equals(order.getStatus())?"15-20":"Preparing".equals(order.getStatus())?"25-30":"30-45";
  double subtotal=0;
  if(order.getItems()!=null) for(CartItem ci:order.getItems()) subtotal+=ci.getSubtotal();
  double delivery=order.getTotal()-subtotal;
  if(delivery<0) delivery=3.0;
%>

  <%-- Confirmed banner --%>
  <% if(confirmed){ %>
  <div class="banner no-print">
    <div class="banner-ic">🎉</div>
    <h2>Order Placed!</h2>
    <p>#<%= order.getId() %> · RM<%= String.format("%.2f",order.getTotal()) %></p>
    <% if(ptsE!=null&&ptsE>0){ %><div class="pts-chip">🌟 +<%= ptsE %> loyalty points!</div><% } %>
  </div>
  <% } %>

  <%-- Tracking steps --%>
  <div class="card no-print">
    <div class="oid-row">
      <div class="oid-num">#<%= order.getId() %></div>
      <div class="oid-dt"><%= order.getDate() %> · <%= order.getTime() %></div>
    </div>
    <div class="steps">
      <div class="steps-line"></div>
      <% for(int i=0;i<stats.length;i++){String sc=i<cur?"done":i==cur?"active":""; %>
      <div class="step <%= sc %>">
        <div class="sic"><%= icons[i] %></div>
        <div class="slbl"><%= stats[i] %></div>
      </div>
      <% } %>
    </div>
    <div class="ri">
      <div class="ri-av"><%= "Delivering".equals(order.getStatus())?"🛵":"👨‍🍳" %></div>
      <div style="flex:1">
        <div class="ri-name"><%= "Delivering".equals(order.getStatus())?"Rider: Ahmad":"Kitchen Team" %></div>
        <div class="ri-sub"><%= "Delivering".equals(order.getStatus())?"📞 +60 12-345 6789":"Preparing your order" %></div>
      </div>
      <div class="eta"><div class="eta-num"><%= eta %></div><div class="eta-lbl">min</div></div>
    </div>
    <div class="addr">📍 <strong><%= order.getCustomerName() %></strong> · <%= order.getCustomerPhone() %><br><%= order.getCustomerAddress() %></div>
  </div>

  <%-- Order items --%>
  <div class="card">
    <div class="card-t">📋 Order Items</div>
    <% if(order.getItems()!=null){ for(CartItem ci:order.getItems()){ %>
    <div class="ir">
      <div class="ir-l">
        <div class="ir-name"><%= ci.getName() %> ×<%= ci.getQty() %></div>
        <% if(ci.getSelectedAddons()!=null&&!ci.getSelectedAddons().isEmpty()){ %>
        <div class="ir-addon">➕ <%= ci.getAddonsDisplay() %></div>
        <% } %>
      </div>
      <div class="ir-p">RM<%= String.format("%.2f",ci.getSubtotal()) %></div>
    </div>
    <% }} %>
    <div class="ir-tot"><span>Total Paid</span><span>RM<%= String.format("%.2f",order.getTotal()) %></span></div>
  </div>

  <%-- Payment summary --%>
  <div class="pay-card no-print">
    <h4>💰 Payment Summary</h4>
    <div class="pg">
      <div class="pi"><div class="pi-num">RM<%= String.format("%.2f",order.getTotal()) %></div><div class="pi-lbl">Total</div></div>
      <div class="pi"><div class="pi-num"><%= order.getPaymentMethod().toUpperCase() %></div><div class="pi-lbl">Method</div></div>
      <div class="pi"><div class="pi-num">RM3.00</div><div class="pi-lbl">Delivery</div></div>
      <div class="pi"><div class="pi-num"><%= order.getStatus() %></div><div class="pi-lbl">Status</div></div>
    </div>
  </div>

  <%-- Print Receipt Button --%>
  <button class="print-btn no-print" onclick="printReceipt()">
    🖨️ Print Receipt
  </button>

  <%-- Auto-refresh --%>
  <% if(!"Delivered".equals(order.getStatus())&&!"Cancelled".equals(order.getStatus())){ %>
  <div class="refresh no-print">🔄 Auto-refreshes every 10s</div>
  <script>setTimeout(()=>location.reload(),10000);</script>
  <% } %>

  <a href="<%= ctx %>/menu" class="back no-print">← Back to Menu</a>

  <%-- ═══════════════════════════════════════
       PRINT RECEIPT — only shows when printing
  ═══════════════════════════════════════ --%>
  <div class="receipt" id="receipt">
    <div class="receipt-wrap">
      <div class="r-header">
        <div class="r-logo">DelivaX Elite</div>
        <div class="r-sub">Arabian Cuisine · Delivered Fresh</div>
        <div class="r-sub">Tel: +60 9-123 4567 | delivax.com.my</div>
        <div class="r-title">Official Receipt</div>
      </div>

      <div class="r-row"><span class="r-key">Receipt No.</span><span class="r-val"><%= order.getId() %></span></div>
      <div class="r-row"><span class="r-key">Date</span><span class="r-val"><%= order.getDate() %></span></div>
      <div class="r-row"><span class="r-key">Time</span><span class="r-val"><%= order.getTime() %></span></div>
      <div class="r-row"><span class="r-key">Customer</span><span class="r-val"><%= order.getCustomerName() %></span></div>
      <div class="r-row"><span class="r-key">Phone</span><span class="r-val"><%= order.getCustomerPhone() %></span></div>
      <div class="r-row"><span class="r-key">Address</span><span class="r-val" style="max-width:55%;text-align:right"><%= order.getCustomerAddress() %></span></div>
      <div class="r-row"><span class="r-key">Payment</span><span class="r-val"><%= order.getPaymentMethod().toUpperCase() %></span></div>
      <div class="r-row"><span class="r-key">Status</span><span class="r-val"><%= order.getStatus() %></span></div>

      <div class="r-divider"></div>
      <div class="r-items-title">Order Items</div>

      <% if(order.getItems()!=null){ for(CartItem ci:order.getItems()){ %>
      <div class="r-item">
        <span><%= ci.getName() %> x<%= ci.getQty() %></span>
        <span>RM<%= String.format("%.2f",ci.getSubtotal()) %></span>
      </div>
      <% if(ci.getSelectedAddons()!=null&&!ci.getSelectedAddons().isEmpty()){ %>
      <div class="r-item-addon">+ <%= ci.getAddonsDisplay() %></div>
      <% } } } %>

      <div class="r-divider"></div>
      <div class="r-row"><span class="r-key">Subtotal</span><span class="r-val">RM<%= String.format("%.2f",subtotal) %></span></div>
      <div class="r-row"><span class="r-key">Delivery Fee</span><span class="r-val">RM<%= String.format("%.2f",Math.max(0,delivery)) %></span></div>
      <div class="r-total"><span>TOTAL</span><span>RM<%= String.format("%.2f",order.getTotal()) %></span></div>

      <% if(ptsE!=null&&ptsE>0){ %>
      <div class="r-loyalty">⭐ Loyalty Points Earned: +<%= ptsE %> pts</div>
      <% } %>

      <div class="r-status">ORDER STATUS: <%= order.getStatus().toUpperCase() %></div>

      <div class="r-footer">
        Thank you for your order!<br>
        DelivaX Elite Sdn Bhd (1234567-A)<br>
        SST No: A01-2345-67890123<br>
        <strong>This is a computer-generated receipt.</strong><br>
        No signature required.
      </div>
    </div>
  </div>

<% } %>
</div>

<script>
function printReceipt() {
  // Show receipt div for printing
  document.getElementById('receipt').style.display = 'block';
  window.print();
  // Hide again after print dialog closes
  setTimeout(()=>{ document.getElementById('receipt').style.display='none'; }, 1000);
}
</script>
</body></html>
