<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.delivax.model.CartItem,com.delivax.util.RoleSession,java.util.*" %>
<%
  Map<String,Object> rs = RoleSession.get(request,"customer");
  if(rs==null){response.sendRedirect(request.getContextPath()+"/login");return;}
  String bankName=(String)rs.get("fpxBank"); if(bankName==null) bankName="FPX";
  String bankCode=(String)rs.get("fpxBankCode"); if(bankCode==null) bankCode="FPX";
  String custName=(String)rs.get("fpxCustomerName"); if(custName==null) custName="";
  String custPhone=(String)rs.get("fpxCustomerPhone"); if(custPhone==null) custPhone="";
  double sub=0;
  @SuppressWarnings("unchecked")
  Map<Integer,CartItem> cart=(Map<Integer,CartItem>)rs.get("cart");
  if(cart!=null) for(CartItem ci:cart.values()) sub+=ci.getSubtotal();
  double disc=0; String dtype=(String)rs.get("discountType");
  Object dobj=rs.get("discount");
  if(dobj instanceof Number) disc=((Number)dobj).doubleValue();
  double delfee="delivery".equals(dtype)?Math.max(0,3.0-disc):3.0;
  double voff="delivery".equals(dtype)?0:disc;
  double total=Math.max(0,sub-voff+delfee);
  String ctx=request.getContextPath();
  String refNum="FPX"+System.currentTimeMillis()+((int)(Math.random()*9999));
%>
<!DOCTYPE html><html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><%= bankName %> – FPX Gateway</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:linear-gradient(135deg,#667eea,#764ba2);
  min-height:100vh;display:flex;flex-direction:column;align-items:center;
  justify-content:flex-start;padding:16px}
/* bank header */
.bank-hdr{background:var(--bank-bg,linear-gradient(135deg,#1a5f7a,#2d6cdf));color:#fff;
  width:100%;max-width:420px;padding:16px 20px;border-radius:14px 14px 0 0;
  display:flex;justify-content:space-between;align-items:center}
.bank-logo{font-size:17px;font-weight:900;display:flex;align-items:center;gap:10px}
.bank-logo-badge{width:42px;height:42px;border-radius:8px;background:rgba(255,255,255,.25);
  display:flex;align-items:center;justify-content:center;font-weight:900;font-size:12px;letter-spacing:-.3px}
.secure{background:rgba(255,255,255,.2);padding:5px 12px;border-radius:20px;
  font-size:10px;font-weight:700;display:flex;align-items:center;gap:5px}
/* container */
.container{background:#fff;width:100%;max-width:420px;border-radius:0 0 16px 16px;
  box-shadow:0 20px 40px rgba(0,0,0,.2);overflow:hidden}
.body{padding:18px}
/* merchant info */
.merchant{background:linear-gradient(135deg,#e8f4fd,#d4ecfa);padding:14px;
  border-radius:10px;margin-bottom:16px;border-left:4px solid #2d6cdf}
.merchant-name{font-weight:900;color:#1a5f7a;font-size:15px;margin-bottom:2px}
.merchant-sub{font-size:11px;color:#4a6fa5}
/* txn details */
.txn-row{display:flex;justify-content:space-between;padding:7px 0;
  border-bottom:1px solid #f0f4fb;font-size:12px}
.txn-row:last-child{border:none}
.txn-lbl{color:#6b7a9a;font-weight:600}
.txn-val{font-weight:800;color:#1a5f7a}
.amt-row{background:linear-gradient(135deg,#2d6cdf,#1a5f7a);color:#fff;
  border-radius:10px;padding:13px 15px;display:flex;justify-content:space-between;
  font-weight:900;font-size:16px;margin-top:10px;margin-bottom:14px}
/* timer */
.timer-box{background:#fff3e0;border:2px solid #ffc107;border-radius:10px;
  padding:10px;margin-bottom:14px;display:flex;align-items:center;justify-content:center;gap:10px}
.timer-num{font-size:22px;font-weight:900;color:#dc3545;font-family:monospace;
  background:#fff;padding:4px 12px;border-radius:7px}
/* login form */
.login-box{background:#f8f9fa;border-radius:10px;padding:16px;margin-bottom:14px}
.login-title{font-size:14px;font-weight:800;color:#1a5f7a;text-align:center;margin-bottom:14px}
.field{margin-bottom:11px}
.fl{display:block;font-size:10px;font-weight:700;color:#6b7a9a;margin-bottom:4px}
.fi{width:100%;padding:10px 12px;border:2px solid #e2e8f0;border-radius:8px;
  font-size:13px;outline:none;transition:border .15s}
.fi:focus{border-color:#2d6cdf}
.tac-btn{width:100%;padding:12px;background:linear-gradient(135deg,#28a745,#20c997);
  color:#fff;border:none;border-radius:9px;font-size:13px;font-weight:800;cursor:pointer;margin-top:4px}
.tac-btn:disabled{background:#adb5bd;cursor:not-allowed}
/* TAC section */
.tac-box{border:2px solid #2d6cdf;border-radius:10px;padding:14px;margin-top:12px;
  display:none;animation:fadeIn .3s}
@keyframes fadeIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.tac-title{color:#2d6cdf;font-weight:800;font-size:13px;margin-bottom:10px;display:flex;align-items:center;gap:6px}
.tac-sub{font-size:11px;color:#e65100;margin-bottom:10px}
.tac-row{display:flex;gap:9px;align-items:center}
.tac-input{flex:2;text-align:center;font-size:22px;letter-spacing:8px;font-weight:900;
  font-family:monospace;padding:12px;border:2px solid #e2e8f0;border-radius:8px;outline:none}
.tac-input:focus{border-color:#2d6cdf}
.tac-input.err{border-color:#dc2626;animation:shake .3s}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-5px)}75%{transform:translateX(5px)}}
.resend{flex:1;background:#e9ecef;color:#2d6cdf;border:none;border-radius:8px;
  padding:10px;font-size:11px;font-weight:700;cursor:pointer;text-align:center}
.resend:hover:not(.dis){background:#2d6cdf;color:#fff}
.resend.dis{opacity:.5;cursor:not-allowed}
.tac-timer{font-size:10px;color:#e65100;text-align:center;margin-top:6px}
.tac-attempts{font-size:10px;color:#dc2626;text-align:center;margin-top:3px}
/* status */
.status{padding:10px 13px;border-radius:8px;font-size:12px;font-weight:600;
  margin-bottom:12px;display:none;text-align:center}
.status.processing{display:block;background:#cce5ff;color:#004085;border-left:4px solid #004085}
.status.success{display:block;background:#d4edda;color:#155724;border-left:4px solid #28a745}
.status.error{display:block;background:#f8d7da;color:#721c24;border-left:4px solid #dc3545}
/* action buttons */
.btns{display:flex;gap:10px;margin-top:14px}
.btn-pay{flex:2;padding:13px;background:linear-gradient(135deg,#1e40af,#1a5f7a);
  color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:800;cursor:pointer}
.btn-pay:disabled{background:#adb5bd;cursor:not-allowed}
.btn-cancel{flex:1;padding:13px;background:#dc3545;color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:800;cursor:pointer}
/* SMS popup */
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99;display:none}
.sms-popup{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);
  background:#fff;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.3);
  z-index:100;width:300px;display:none}
.sms-hdr{background:linear-gradient(135deg,#28a745,#20c997);color:#fff;
  padding:14px;border-radius:16px 16px 0 0;display:flex;align-items:center;gap:8px;font-weight:800}
.sms-body{padding:18px;text-align:center}
.sms-code{font-size:30px;font-weight:900;color:#2d6cdf;letter-spacing:6px;
  font-family:monospace;background:#f8f9fa;padding:12px;border-radius:9px;margin:12px 0}
.sms-close{width:100%;padding:11px;background:#2d6cdf;color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:700}
</style>
</head>
<body>
<div class="bank-hdr" id="bankHdrEl">
  <div class="bank-logo">
    <div class="bank-logo-badge" id="bankBadge"><%= bankCode.length()>4?bankCode.substring(0,4):bankCode %></div>
    <span id="bankNameHdr"><%= bankName %></span>
  </div>
  <div class="secure">🔒 SECURE</div>
</div>
<div class="container">
  <div class="body">
    <div class="merchant">
      <div class="merchant-name">🏪 Merchant: DelivaX Elite</div>
      <div class="merchant-sub">Transaction via FPX (Financial Process Exchange)</div>
    </div>
    <div class="txn-row"><span class="txn-lbl">Reference No.</span><span class="txn-val"><%= refNum %></span></div>
    <div class="txn-row"><span class="txn-lbl">Date & Time</span><span class="txn-val" id="dt"></span></div>
    <div class="txn-row"><span class="txn-lbl">Merchant</span><span class="txn-val">DelivaX Elite Sdn Bhd</span></div>
    <div class="txn-row"><span class="txn-lbl">Selected Bank</span><span class="txn-val"><%= bankName %></span></div>
    <div class="amt-row"><span>💰 Amount to Pay:</span><span>RM<%= String.format("%.2f",total) %></span></div>

    <div class="timer-box">
      ⏳ Time remaining: <span class="timer-num" id="timer">10:00</span>
    </div>

    <!-- Bank login form -->
    <div class="login-box">
      <div class="login-title">🔐 Secure Login to <%= bankName %></div>
      <div class="field"><label class="fl">Username / User ID</label>
        <input class="fi" id="uname" placeholder="Enter your online banking username"></div>
      <div class="field"><label class="fl">Password</label>
        <input class="fi" id="upass" type="password" placeholder="Enter your password"></div>
      <button class="tac-btn" id="tacBtn" onclick="requestTAC()">📱 Request TAC (Transaction Authorization Code)</button>

      <!-- TAC entry -->
      <div class="tac-box" id="tacBox">
        <div class="tac-title">🔑 Enter TAC Code</div>
        <div class="tac-sub">ℹ️ A 6-digit TAC has been sent to your registered mobile number</div>
        <div class="tac-row">
          <input class="tac-input" id="tacCode" placeholder="000000" maxlength="6"
                 oninput="this.value=this.value.replace(/[^0-9]/g,'');enablePay()">
          <button class="resend" id="resendBtn" onclick="resendTAC()">🔄 Resend</button>
        </div>
        <div class="tac-timer">TAC expires in: <span id="tacExp">05:00</span></div>
        <div class="tac-attempts">Remaining attempts: <span id="attempts">3</span></div>
      </div>
    </div>

    <div class="status" id="status"></div>

    <div class="btns">
      <button class="btn-cancel" onclick="cancelPayment()">✕ Cancel</button>
      <button class="btn-pay" id="payBtn" onclick="verifyAndPay()" disabled>🔒 Confirm & Pay</button>
    </div>
  </div>
</div>

<!-- SMS popup -->
<div class="overlay" id="overlay" onclick="closeSMS()"></div>
<div class="sms-popup" id="smsPopup">
  <div class="sms-hdr">📩 SMS from Bank</div>
  <div class="sms-body">
    <div style="font-size:38px;margin-bottom:8px">📱</div>
    <p style="font-size:13px;color:#374151">Your TAC code is:</p>
    <div class="sms-code" id="smsCode">000000</div>
    <p style="font-size:11px;color:#9ca3af;margin-bottom:12px">Valid for 5 minutes. Do not share this code.</p>
    <button class="sms-close" onclick="closeSMS()">OK, I got it</button>
  </div>
</div>

<script>
const CTX='<%= ctx %>';
const BANK_COLORS={
  MAYBANK:{bg:'#f5e642',fg:'#000'},
  CIMB:{bg:'#c0392b',fg:'#fff'},
  PUBLIC:{bg:'#1a5276',fg:'#fff'},
  RHB:{bg:'#e74c3c',fg:'#fff'},
  HONGLEONG:{bg:'#1e3a8a',fg:'#fff'},
  AMBANK:{bg:'#e67e22',fg:'#fff'},
  BANKISLAM:{bg:'#1d6a3a',fg:'#fff'},
  BANKRAKYAT:{bg:'#6c3483',fg:'#fff'},
  AFFIN:{bg:'#117a65',fg:'#fff'},
  ALLIANCE:{bg:'#1f618d',fg:'#fff'}
};
const bankCode='<%= bankCode %>';
const bc=BANK_COLORS[bankCode]||{bg:'#1a5f7a',fg:'#fff'};
document.getElementById('bankHdrEl').style.background=bc.bg;
document.getElementById('bankHdrEl').style.color=bc.fg;
document.getElementById('bankBadge').style.color=bc.fg;
let tac=null, tacGenerated=false, tacAttempts=3;
let timeLeft=600, tacLeft=300, expired=false, processing=false;
let mainTimer, tacTimer;

document.getElementById('dt').textContent=new Date().toLocaleString('en-MY');

// Main countdown
mainTimer=setInterval(()=>{
  if(timeLeft<=0){clearInterval(mainTimer);expired=true;
    document.getElementById('timer').textContent='00:00';
    document.getElementById('timer').style.color='#dc2626';
    document.getElementById('tacBtn').disabled=true;
    document.getElementById('payBtn').disabled=true;
    showStatus('Payment session expired. Please go back and try again.','error');
    return;
  }
  timeLeft--;
  const m=Math.floor(timeLeft/60),s=timeLeft%60;
  document.getElementById('timer').textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;
  if(timeLeft<=60) document.getElementById('timer').style.color='#dc2626';
},1000);

function requestTAC(){
  const u=document.getElementById('uname').value.trim();
  const p=document.getElementById('upass').value.trim();
  if(!u||!p){showStatus('Please enter your username and password.','error');return;}
  showStatus('Verifying credentials and sending TAC...','processing');
  document.getElementById('tacBtn').disabled=true;
  setTimeout(()=>{
    tac=(Math.floor(100000+Math.random()*900000)).toString();
    tacGenerated=true; tacAttempts=3;
    document.getElementById('attempts').textContent=3;
    document.getElementById('tacCode').value='';
    document.getElementById('smsCode').textContent=tac;
    document.getElementById('overlay').style.display='block';
    document.getElementById('smsPopup').style.display='block';
    document.getElementById('tacBox').style.display='block';
    startTACTimer();
    showStatus('TAC sent to your registered mobile number.','success');
    setTimeout(()=>{ const s=document.getElementById('status'); if(s.classList.contains('success')) s.style.display='none'; },3000);
    document.getElementById('tacBtn').disabled=false;
  },2000);
}

function startTACTimer(){
  tacLeft=300; clearInterval(tacTimer);
  tacTimer=setInterval(()=>{
    if(tacLeft<=0){clearInterval(tacTimer);
      document.getElementById('tacExp').textContent='00:00';
      showStatus('TAC expired. Please request a new TAC.','error');
      document.getElementById('payBtn').disabled=true; tacGenerated=false; return;
    }
    tacLeft--;
    const m=Math.floor(tacLeft/60),s=tacLeft%60;
    document.getElementById('tacExp').textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;
  },1000);
}

function resendTAC(){
  const btn=document.getElementById('resendBtn');
  if(btn.classList.contains('dis')){showStatus('Please wait before resending.','error');return;}
  showStatus('Resending TAC...','processing');
  btn.classList.add('dis');
  setTimeout(()=>btn.classList.remove('dis'),30000);
  setTimeout(()=>{
    tac=(Math.floor(100000+Math.random()*900000)).toString();
    tacAttempts=3; document.getElementById('attempts').textContent=3;
    document.getElementById('tacCode').value='';
    document.getElementById('tacCode').classList.remove('err');
    document.getElementById('smsCode').textContent=tac;
    document.getElementById('overlay').style.display='block';
    document.getElementById('smsPopup').style.display='block';
    startTACTimer();
    showStatus('New TAC sent to your registered mobile number.','success');
  },1500);
}

function enablePay(){
  const v=document.getElementById('tacCode').value;
  document.getElementById('payBtn').disabled=v.length!==6;
}

function closeSMS(){
  document.getElementById('overlay').style.display='none';
  document.getElementById('smsPopup').style.display='none';
}

function verifyAndPay(){
  if(processing||expired) return;
  const entered=document.getElementById('tacCode').value.trim();
  const tacInput=document.getElementById('tacCode');
  if(!tacGenerated){showStatus('Please request TAC first.','error');return;}
  if(entered.length!==6){showStatus('Please enter a valid 6-digit TAC.','error');tacInput.classList.add('err');return;}
  if(entered!==tac){
    tacAttempts--;
    document.getElementById('attempts').textContent=tacAttempts;
    tacInput.classList.add('err');
    setTimeout(()=>tacInput.classList.remove('err'),500);
    if(tacAttempts<=0){
      showStatus('Too many invalid attempts. Requesting new TAC...','error');
      document.getElementById('payBtn').disabled=true;
      setTimeout(()=>requestTAC(),2000);
    } else {
      showStatus('Invalid TAC. '+tacAttempts+' attempt(s) remaining.','error');
    }
    return;
  }
  // TAC correct — process payment
  processPayment();
}

function processPayment(){
  processing=true;
  clearInterval(mainTimer); clearInterval(tacTimer);
  showStatus('Processing payment... Please do not close this window.','processing');
  document.getElementById('payBtn').disabled=true;
  document.getElementById('tacBtn').disabled=true;
  setTimeout(()=>{
    const txnId='TXN'+Date.now()+Math.floor(Math.random()*9999);
    showStatus('✅ Payment successful! Redirecting...','success');
    // Submit to server to confirm and place order
    const f=document.createElement('form'); f.method='post'; f.action=CTX+'/fpx';
    const add=(n,v)=>{const i=document.createElement('input');i.type='hidden';i.name=n;i.value=v;f.appendChild(i);};
    add('step','done'); add('txnId',txnId);
    document.body.appendChild(f); f.submit();
  },3000);
}

function showStatus(msg,type){
  const s=document.getElementById('status');
  s.textContent=msg; s.className='status '+type;
  s.style.display='block';
  if(type!=='processing') setTimeout(()=>{if(!s.classList.contains('processing'))s.style.display='none';},5000);
}

function cancelPayment(){
  if(confirm('Are you sure you want to cancel this payment?'))
    window.location.href=CTX+'/checkout';
}
</script>
</body></html>
