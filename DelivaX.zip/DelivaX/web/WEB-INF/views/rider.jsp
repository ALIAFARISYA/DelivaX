<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.delivax.model.*,java.util.*" %>
<%
  @SuppressWarnings("unchecked")
  List<Order> active=(List<Order>)request.getAttribute("activeOrders");
  @SuppressWarnings("unchecked")
  List<Order> history=(List<Order>)request.getAttribute("historyOrders");
  long toPickup=request.getAttribute("toPickup")!=null?(Long)request.getAttribute("toPickup"):0;
  long delivering=request.getAttribute("delivering")!=null?(Long)request.getAttribute("delivering"):0;
  long delivered=request.getAttribute("delivered")!=null?(Long)request.getAttribute("delivered"):0;
  if(active==null) active=new ArrayList<>();
  if(history==null) history=new ArrayList<>();
  java.util.Map<String,Object> riderRs=com.delivax.util.RoleSession.get(request,"rider");
  Integer rd=riderRs!=null&&riderRs.get("riderDeliveries") instanceof Integer?(Integer)riderRs.get("riderDeliveries"):null;
  Double re=riderRs!=null&&riderRs.get("riderEarnings") instanceof Double?(Double)riderRs.get("riderEarnings"):null;
  int dc=rd!=null?rd:0; double earn=re!=null?re:0.0;
  String ctx=request.getContextPath();
%>
<!DOCTYPE html><html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Rider Dashboard</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:#f0fdf4;color:#1e2d50;font-size:13px}
.page{max-width:480px;margin:0 auto;padding:0 0 20px}
.tb{background:linear-gradient(135deg,#065f46,#059669);color:#fff;height:48px;
  padding:0 12px;display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:100;box-shadow:0 2px 10px rgba(6,95,70,.4)}
.tb-logo{font-size:15px;font-weight:900}.tb-logo span{color:#fbbf24}
.tb-btn{background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.26);
  color:#fff;border-radius:14px;padding:4px 11px;font-size:11px;font-weight:700;text-decoration:none}
/* stats */
.stats{display:flex;gap:5px;padding:8px 12px}
.st{flex:1;background:#fff;border-radius:8px;padding:7px 4px;text-align:center;
  border:1px solid #d1fae5;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.sn{font-size:20px;font-weight:900;color:#059669;line-height:1}
.sn.bl{color:#2d6cdf}.sn.gr{color:#16a34a}
.sl{font-size:8px;font-weight:700;color:#9ca3af;text-transform:uppercase;margin-top:2px}
/* earnings banner */
.earn{background:linear-gradient(135deg,#065f46,#059669);color:#fff;
  border-radius:9px;padding:9px 12px;margin:0 12px 6px;
  display:flex;align-items:center;justify-content:space-between}
.earn-left{}
.earn-sub{font-size:9px;opacity:.8}
.earn-amt{font-size:22px;font-weight:900;line-height:1.1}
.earn-pills{display:flex;gap:6px}
.ep{background:rgba(255,255,255,.18);border-radius:6px;padding:5px 8px;text-align:center}
.ep-num{font-size:14px;font-weight:900}
.ep-lbl{font-size:8px;opacity:.8}
/* tabs */
.tabs{display:flex;gap:0;margin:0 12px 6px;background:#dcfce7;border-radius:8px;padding:2px}
.tab{flex:1;text-align:center;padding:6px;font-size:11px;font-weight:700;cursor:pointer;
  border-radius:6px;color:#065f46;border:none;background:none}
.tab.on{background:#fff;color:#059669;box-shadow:0 1px 3px rgba(5,150,105,.15)}
/* order card — compact */
.oc{background:#fff;border-radius:9px;border-left:3px solid #e2e8f0;
  margin:0 12px 6px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.06)}
.oc.rdy{border-left-color:#059669}.oc.del{border-left-color:#2d6cdf}
/* header row */
.oh{display:flex;align-items:center;gap:5px;padding:7px 10px;cursor:pointer;min-height:42px}
.oh:hover{background:#f0fdf4}
.o-id{font-size:12px;font-weight:900;color:#059669;white-space:nowrap;min-width:55px}
.o-addr{flex:1;font-size:11px;font-weight:600;color:#374151;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.o-amt{font-size:12px;font-weight:900;color:#059669;white-space:nowrap}
.bdg{display:inline-block;padding:2px 6px;border-radius:8px;font-size:8px;font-weight:800;text-transform:uppercase;flex-shrink:0;white-space:nowrap}
.br{background:#d1fae5;color:#065f46}.bd2{background:#dbeafe;color:#1e40af}
.chev{font-size:10px;color:#9ca3af;flex-shrink:0;transition:transform .2s}
.chev.op{transform:rotate(180deg)}
/* action buttons — always visible, big tap targets */
.ar{display:flex;gap:6px;padding:0 10px 8px}
.abtn{flex:1;padding:10px 6px;border:none;border-radius:8px;font-size:12px;
  font-weight:800;cursor:pointer;text-align:center;text-decoration:none;
  display:flex;align-items:center;justify-content:center;gap:4px}
.abtn-pu{background:#1e40af;color:#fff}
.abtn-dl{background:#059669;color:#fff}
.abtn-mp{background:#f0f4fb;color:#374151}
.abtn:hover{opacity:.88}
/* detail body */
.ob{display:none;border-top:1px solid #f0fdf4;padding:7px 10px;font-size:11px}
.ob.on{display:block}
.dr{display:flex;justify-content:space-between;align-items:baseline;
  padding:3px 0;border-bottom:1px dotted #f0fdf4;font-size:11px}
.dr:last-child{border:none}
.dl{color:#6b7a9a;font-weight:600;min-width:65px}.dv{font-weight:700;text-align:right;flex:1}
/* history */
.hc{background:#fff;border-radius:9px;border-left:3px solid #d1fae5;
  margin:0 12px 5px;overflow:hidden}
.hh{display:flex;align-items:center;gap:5px;padding:7px 10px;cursor:pointer;min-height:40px}
.hh:hover{background:#f0fdf4}
.hb{display:none;border-top:1px solid #f0fdf4;padding:7px 10px;font-size:11px}
.hb.on{display:block}
.empty{text-align:center;padding:30px 16px;color:#9ca3af}
</style>
</head>
<body>
<div class="tb">
  <div>
    <div class="tb-logo">🛵 Rider <span>Dashboard</span></div>
    <div style="font-size:9px;opacity:.7"><%= com.delivax.util.RoleSession.getAttribute(request,"rider","user") %></div>
  </div>
  <a href="<%= ctx %>/logout?role=rider" class="tb-btn">Logout</a>
</div>
<div class="page">
  <div class="stats">
    <div class="st"><div class="sn"><%= toPickup %></div><div class="sl">Pickup</div></div>
    <div class="st"><div class="sn bl"><%= delivering %></div><div class="sl">Going</div></div>
    <div class="st"><div class="sn gr"><%= delivered %></div><div class="sl">Done</div></div>
  </div>
  <div class="earn">
    <div class="earn-left">
      <div class="earn-sub">Today's Earnings</div>
      <div class="earn-amt">RM<%= String.format("%.2f",earn) %></div>
    </div>
    <div class="earn-pills">
      <div class="ep"><div class="ep-num"><%= dc %></div><div class="ep-lbl">Trips</div></div>
      <div class="ep"><div class="ep-num">RM3</div><div class="ep-lbl">Each</div></div>
      <div class="ep"><div class="ep-num"><%= dc>0?"⭐":"🆕" %></div><div class="ep-lbl">Rating</div></div>
    </div>
  </div>
  <div class="tabs">
    <button class="tab on" id="ta" onclick="showTab('a')">🔴 Active (<%= active.size() %>)</button>
    <button class="tab" id="th" onclick="showTab('h')">✅ History (<%= history.size() %>)</button>
  </div>

  <!-- ACTIVE -->
  <div id="pa">
  <% if(active.isEmpty()){ %>
  <div class="empty"><div style="font-size:36px;margin-bottom:6px">🛵</div><p style="font-size:12px;font-weight:600">No active deliveries</p></div>
  <% }else{ for(int i=0;i<active.size();i++){ Order o=active.get(i); boolean isRdy="Ready".equals(o.getStatus()); %>
  <div class="oc <%= isRdy?"rdy":"del" %>">
    <!-- compact header: ID · address preview · amount · badge · chevron -->
    <div class="oh" onclick="tog('od<%=i%>','oc<%=i%>')">
      <div class="o-id">#<%= o.getId() %></div>
      <div class="o-addr">📍 <%= o.getCustomerAddress() %></div>
      <div class="o-amt">RM<%= String.format("%.2f",o.getTotal()) %></div>
      <span class="bdg <%= isRdy?"br":"bd2" %>"><%= o.getStatus() %></span>
      <span class="chev" id="oc<%=i%>">▼</span>
    </div>
    <!-- action buttons — always visible -->
    <div class="ar">
      <% if(isRdy){ %>
      <form method="post" action="<%= ctx %>/rider" style="flex:2;display:contents">
        <input type="hidden" name="orderId" value="<%= o.getId() %>">
        <input type="hidden" name="status" value="Delivering">
        <button type="submit" class="abtn abtn-pu" style="flex:2">🛵 Pick Up</button>
      </form>
      <% }else{ %>
      <form method="post" action="<%= ctx %>/rider" style="flex:2;display:contents">
        <input type="hidden" name="orderId" value="<%= o.getId() %>">
        <input type="hidden" name="status" value="Delivered">
        <button type="submit" class="abtn abtn-dl" style="flex:2">✅ Delivered</button>
      </form>
      <a href="https://maps.google.com/?q=<%= java.net.URLEncoder.encode(o.getCustomerAddress(),"UTF-8") %>"
         class="abtn abtn-mp" style="flex:1;text-decoration:none" target="_blank">📍 Map</a>
      <% } %>
    </div>
    <!-- detail on expand -->
    <div class="ob" id="od<%=i%>">
      <div class="dr"><span class="dl">Customer</span><span class="dv"><%= o.getCustomerName() %></span></div>
      <div class="dr"><span class="dl">Phone</span><span class="dv"><a href="tel:<%= o.getCustomerPhone() %>" style="color:#059669"><%= o.getCustomerPhone() %></a></span></div>
      <div class="dr"><span class="dl">Items</span><span class="dv"><%= o.getItemsSummary() %></span></div>
      <div class="dr"><span class="dl">Payment</span><span class="dv"><%= o.getPaymentMethod().toUpperCase() %></span></div>
      <div class="dr" style="border:none"><span class="dl">Rider Fee</span><span class="dv" style="color:#059669;font-weight:900">RM 3.00</span></div>
    </div>
  </div>
  <% }} %>
  </div>

  <!-- HISTORY -->
  <div id="ph" style="display:none">
  <% if(history.isEmpty()){ %>
  <div class="empty"><div style="font-size:36px;margin-bottom:6px">📋</div><p style="font-size:12px;font-weight:600">No delivery history yet</p></div>
  <% }else{ for(int i=0;i<history.size();i++){ Order o=history.get(i); %>
  <div class="hc">
    <div class="hh" onclick="tog('hbd<%=i%>','hbc<%=i%>')">
      <div class="o-id" style="font-size:11px">#<%= o.getId() %></div>
      <div class="o-addr"><%= o.getCustomerName() %> · <%= o.getTime() %></div>
      <div class="o-amt">RM<%= String.format("%.2f",o.getTotal()) %></div>
      <span style="font-size:9px;color:#059669;font-weight:800;white-space:nowrap">+RM3 ✅</span>
      <span class="chev" id="hbc<%=i%>">▼</span>
    </div>
    <div class="hb" id="hbd<%=i%>">
      <div class="dr"><span class="dl">Customer</span><span class="dv"><%= o.getCustomerName() %></span></div>
      <div class="dr"><span class="dl">Phone</span><span class="dv"><%= o.getCustomerPhone() %></span></div>
      <div class="dr"><span class="dl">Address</span><span class="dv"><%= o.getCustomerAddress() %></span></div>
      <div class="dr"><span class="dl">Items</span><span class="dv"><%= o.getItemsSummary() %></span></div>
      <div class="dr" style="border:none"><span class="dl">Fee Earned</span><span class="dv" style="color:#059669;font-weight:900">RM 3.00</span></div>
    </div>
  </div>
  <% }} %>
  </div>
</div>
<script>
function tog(bid,cid){const b=document.getElementById(bid),c=document.getElementById(cid);b.classList.toggle('on');if(c)c.classList.toggle('op');}
function showTab(t){['a','h'].forEach(x=>{document.getElementById('p'+x).style.display=x===t?'block':'none';document.getElementById('t'+x).classList.toggle('on',x===t);});}
setTimeout(()=>location.reload(),10000);
</script>
</body></html>
