<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.delivax.model.CartItem,java.util.*" %>
<%
  java.util.Map<String,Object> rs=com.delivax.util.RoleSession.get(request,"customer");
  if(rs==null) rs=new java.util.HashMap<>();
  @SuppressWarnings("unchecked")
  Map<Integer,CartItem> cart=(Map<Integer,CartItem>)rs.get("cart");
  if(cart==null) cart=new LinkedHashMap<>();
  double sub=0; for(CartItem ci:cart.values()) sub+=ci.getSubtotal();
  double disc=0; String dtype=(String)rs.get("discountType");
  Object dobj=rs.get("discount");
  if(dobj instanceof Number) disc=((Number)dobj).doubleValue();
  String voucher=(String)rs.get("voucher");
  double delfee="delivery".equals(dtype)?Math.max(0,3.0-disc):3.0;
  double voff="delivery".equals(dtype)?0:disc;
  double total=Math.max(0,sub-voff+delfee);
  String cerr=(String)rs.get("checkoutErr");
  if(cerr!=null) rs.remove("checkoutErr");
  String uname=(String)rs.get("user");
  String ctx=request.getContextPath();
%>
<!DOCTYPE html><html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DelivaX – Checkout</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:#f1f5f9;color:#1e2d50;font-size:13px}
.page{max-width:420px;margin:0 auto;padding:0 0 20px}
.tb{background:linear-gradient(135deg,#1e40af,#2d6cdf);color:#fff;height:48px;
  padding:0 12px;display:flex;align-items:center;justify-content:space-between;
  box-shadow:0 2px 10px rgba(30,64,175,.35)}
.tb-logo{font-size:17px;font-weight:900}.tb-logo span{color:#fbbf24}
.tb-btn{background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.26);
  color:#fff;border-radius:14px;padding:4px 11px;font-size:11px;font-weight:700;text-decoration:none}
/* section card */
.sc{background:#fff;border-radius:10px;border:1px solid #e2e8f0;
  margin:8px 12px 0;padding:10px 12px}
.sc-t{font-size:10px;font-weight:800;text-transform:uppercase;
  letter-spacing:.5px;color:#9ca3af;margin-bottom:8px}
/* order recap */
.or{display:flex;justify-content:space-between;align-items:flex-start;
  padding:3px 0;border-bottom:1px dotted #f1f5f9;font-size:12px}
.or:last-of-type{border:none}
.or-l{flex:1;min-width:0}
.or-name{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.or-addon{font-size:10px;color:#7c3aed;font-weight:600;margin-top:1px}
.or-p{font-weight:800;color:#1e40af;white-space:nowrap;margin-left:8px;flex-shrink:0}
.div{border:none;border-top:1px solid #f1f5f9;margin:6px 0}
.sr{display:flex;justify-content:space-between;padding:2px 0;font-size:12px;font-weight:600}
.sr.tot{font-weight:900;font-size:13px;color:#1e40af;
  border-top:1.5px solid #e2e8f0;padding-top:6px;margin-top:4px}
.sr.sv{color:#16a34a}
/* form */
.field{margin-bottom:9px}
.fl{display:block;font-size:9px;font-weight:800;text-transform:uppercase;
  letter-spacing:.5px;color:#9ca3af;margin-bottom:3px}
.fi{width:100%;padding:8px 10px;border:1.5px solid #e2e8f0;border-radius:7px;
  font-size:12px;font-family:inherit;outline:none;transition:border .15s}
.fi:focus{border-color:#1e40af}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:7px}
/* payment */
.pay-row{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:8px}
.po{background:#f8faff;border:2px solid #e2e8f0;border-radius:8px;
  padding:8px 4px;cursor:pointer;text-align:center;
  font-size:11px;font-weight:700;color:#64748b;transition:all .15s}
.po.on{border-color:#1e40af;background:#eff6ff;color:#1e40af}
.po .pi{display:block;font-size:18px;margin-bottom:3px}
/* submit */
.btn{display:block;width:100%;padding:12px;margin:10px 12px 0;width:calc(100% - 24px);
  background:linear-gradient(135deg,#1e40af,#2563eb);
  color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:800;cursor:pointer}
.btn:hover{opacity:.9}
.al-err{background:#fef2f2;color:#dc2626;border:1px solid #fecaca;
  padding:7px 10px;border-radius:7px;font-size:11px;font-weight:600;margin:8px 12px 0}
</style>
</head>
<body>
<div class="tb">
  <div><div class="tb-logo">Deliva<span>X</span></div>
    <div style="font-size:9px;opacity:.7">Checkout 💳</div></div>
  <a href="<%= ctx %>/cart" class="tb-btn">← Cart</a>
</div>
<div class="page">
<% if(cerr!=null){ %><div class="al-err">⚠️ <%= cerr %></div><% } %>
<form method="post" action="<%= ctx %>/checkout">
  <!-- Order summary -->
  <div class="sc">
    <div class="sc-t">Order Summary</div>
    <% for(CartItem ci:cart.values()){ %>
    <div class="or">
      <div class="or-l">
        <div class="or-name"><%= ci.getName() %> ×<%= ci.getQty() %></div>
        <% if(ci.getSelectedAddons()!=null&&!ci.getSelectedAddons().isEmpty()){ %>
        <div class="or-addon">➕ <%= ci.getAddonsDisplay() %></div>
        <% } %>
      </div>
      <div class="or-p">RM<%= String.format("%.2f",ci.getSubtotal()) %></div>
    </div>
    <% } %>
    <div class="div"></div>
    <% if(voff>0){ %>
    <div class="sr sv"><span>Voucher (<%= voucher %>)</span><span>−RM<%= String.format("%.2f",voff) %></span></div>
    <% } %>
    <div class="sr"><span>Delivery fee</span><span>RM<%= String.format("%.2f",delfee) %></span></div>
    <div class="sr tot"><span>Total Payable</span><span>RM<%= String.format("%.2f",total) %></span></div>
  </div>
  <!-- Delivery details -->
  <div class="sc" style="margin-top:8px">
    <div class="sc-t">Delivery Details</div>
    <div class="field"><label class="fl">Full Name</label>
      <input class="fi" name="name" value="<%= uname!=null?uname:"" %>" placeholder="Ahmad bin Ali" required></div>
    <div class="field"><label class="fl">Phone</label>
      <input class="fi" name="phone" placeholder="+60 12-345 6789" required></div>
    <div class="field"><label class="fl">Address</label>
      <input class="fi" name="address" placeholder="No. 5, Jalan Cenderawasih..." required></div>
    <div class="row2">
      <div class="field"><label class="fl">Postcode</label><input class="fi" name="postcode" placeholder="20000"></div>
      <div class="field"><label class="fl">City</label><input class="fi" name="city" placeholder="KL"></div>
    </div>
  </div>
  <!-- Payment -->
  <div class="sc" style="margin-top:8px">
    <div class="sc-t">Payment Method</div>
    <div class="pay-row">
      <div class="po on" id="pm-card" onclick="setPay('card',this)"><span class="pi">💳</span>Card</div>
      <div class="po" id="pm-fpx"  onclick="setPay('fpx',this)"><span class="pi">🏦</span>FPX</div>
      <div class="po" id="pm-cod"  onclick="setPay('cod',this)"><span class="pi">💵</span>Cash</div>
    </div>
    <input type="hidden" name="payment" id="pay-val" value="card">
    <div id="card-fields">
      <div class="field"><label class="fl">Card Number</label>
        <input class="fi" placeholder="4242 4242 4242 4242" maxlength="19"></div>
      <div class="row2">
        <div class="field"><label class="fl">Expiry</label><input class="fi" placeholder="MM/YY"></div>
        <div class="field"><label class="fl">CVV</label><input class="fi" placeholder="123" maxlength="3"></div>
      </div>
    </div>
  </div>
  <button type="submit" class="btn">✓ Place Order — RM<%= String.format("%.2f",total) %></button>
</form>
</div>
<script>
function setPay(m,el){
  document.getElementById('pay-val').value=m;
  document.querySelectorAll('.po').forEach(b=>b.classList.remove('on'));
  el.classList.add('on');
  document.getElementById('card-fields').style.display=m==='card'?'block':'none';
}
</script>
</body></html>
