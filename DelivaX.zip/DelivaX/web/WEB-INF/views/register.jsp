<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DelivaX – Register</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{
  font-family:'Segoe UI',sans-serif;
  min-height:100vh;
  background:linear-gradient(160deg,#0f172a 0%,#1e3a8a 50%,#1e40af 100%);
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  padding:24px 16px;
}
.brand{text-align:center;margin-bottom:28px}
.brand-logo{font-size:38px;font-weight:900;color:#fff;letter-spacing:-1.5px}
.brand-logo span{color:#fbbf24}
.brand-tag{font-size:13px;color:rgba(255,255,255,.6);margin-top:6px}

.card{background:#fff;border-radius:20px;width:100%;max-width:380px;
  box-shadow:0 24px 80px rgba(0,0,0,.35);overflow:hidden}
.card-header{background:linear-gradient(135deg,#059669,#065f46);padding:20px 24px 18px;color:#fff}
.card-header h2{font-size:20px;font-weight:800;margin-bottom:2px}
.card-header p{font-size:12px;opacity:.75}
.card-body{padding:22px 24px 26px}

.field{margin-bottom:14px}
.fl{display:block;font-size:10px;font-weight:800;text-transform:uppercase;
  letter-spacing:.7px;color:#94a3b8;margin-bottom:5px}
.fi{
  width:100%;padding:11px 13px;
  border:1.5px solid #e2e8f0;border-radius:9px;
  font-size:14px;font-family:inherit;color:#1e2d50;
  outline:none;background:#fff;transition:border .15s,box-shadow .15s;
}
.fi:focus{border-color:#059669;box-shadow:0 0 0 3px rgba(5,150,105,.1)}
.fi-hint{font-size:10px;color:#94a3b8;margin-top:4px}

/* Password strength */
.strength-bar{height:4px;border-radius:2px;background:#e2e8f0;margin-top:6px;overflow:hidden}
.strength-fill{height:100%;border-radius:2px;transition:width .3s,background .3s}
.strength-lbl{font-size:10px;margin-top:3px;font-weight:600}

.btn-primary{
  width:100%;padding:13px;margin-top:6px;
  background:linear-gradient(135deg,#059669,#065f46);
  color:#fff;border:none;border-radius:10px;
  font-size:14px;font-weight:800;cursor:pointer;transition:opacity .15s;
}
.btn-primary:hover{opacity:.9}

.alert-err{background:#fef2f2;color:#dc2626;border:1px solid #fecaca;
  padding:10px 13px;border-radius:9px;font-size:12px;font-weight:600;margin-bottom:16px;
  display:flex;gap:8px;line-height:1.5}

.card-footer{border-top:1px solid #f1f5f9;padding:14px 24px;text-align:center;font-size:12px;color:#64748b}
.card-footer a{color:#2d6cdf;font-weight:700;text-decoration:none}
.card-footer a:hover{text-decoration:underline}

.info-box{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:9px;
  padding:10px 13px;font-size:12px;color:#065f46;margin-bottom:16px;line-height:1.6}
.info-box strong{font-weight:800}
</style>
</head>
<body>

<div class="brand">
  <div class="brand-logo">Deliva<span>X</span></div>
  <div class="brand-tag">🍢 Arabian cuisine · Delivered fresh</div>
</div>

<div class="card">
  <div class="card-header">
    <h2>Create Account 🛍️</h2>
    <p>Register as a customer to start ordering</p>
  </div>

  <div class="card-body">
    <div class="info-box">
      <strong>ℹ️ Customer registration only.</strong><br>
      Staff and rider accounts are managed by the admin.
    </div>

    <% if (request.getAttribute("error") != null) { %>
    <div class="alert-err">⚠️ ${error}</div>
    <% } %>

    <form method="post" action="${pageContext.request.contextPath}/register">
      <div class="field">
        <label class="fl">Full Name</label>
        <input class="fi" name="name" placeholder="e.g. Ahmad bin Ali" required
               value="${param.name}" autocomplete="name">
        <div class="fi-hint">This will be your username for login</div>
      </div>

      <div class="field">
        <label class="fl">Password</label>
        <input class="fi" type="password" name="password" id="pw"
               placeholder="Min 6 characters" required autocomplete="new-password"
               oninput="checkStrength(this.value)">
        <div class="strength-bar"><div class="strength-fill" id="sf" style="width:0"></div></div>
        <div class="strength-lbl" id="sl" style="color:#94a3b8"></div>
      </div>

      <div class="field">
        <label class="fl">Confirm Password</label>
        <input class="fi" type="password" name="confirm" id="cf"
               placeholder="Re-enter password" required autocomplete="new-password"
               oninput="checkMatch()">
        <div class="fi-hint" id="match-lbl"></div>
      </div>

      <button type="submit" class="btn-primary">Create Account →</button>
    </form>
  </div>

  <div class="card-footer">
    Already have an account? <a href="${pageContext.request.contextPath}/login">Login here →</a>
  </div>
</div>

<script>
function checkStrength(pw) {
  const f = document.getElementById('sf');
  const l = document.getElementById('sl');
  let score = 0;
  if (pw.length >= 6)  score++;
  if (pw.length >= 10) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const w = ['0%','25%','45%','65%','85%','100%'][score];
  const colors = ['#e2e8f0','#ef4444','#f97316','#eab308','#22c55e','#16a34a'];
  const labels = ['','Too short','Weak','Fair','Good','Strong'];
  f.style.width = w; f.style.background = colors[score];
  l.textContent = labels[score]; l.style.color = colors[score];
}
function checkMatch() {
  const pw = document.getElementById('pw').value;
  const cf = document.getElementById('cf').value;
  const el = document.getElementById('match-lbl');
  if (!cf) { el.textContent = ''; return; }
  if (pw === cf) { el.textContent = '✓ Passwords match'; el.style.color = '#16a34a'; }
  else           { el.textContent = '✗ Passwords do not match'; el.style.color = '#ef4444'; }
}
</script>
</body>
</html>
