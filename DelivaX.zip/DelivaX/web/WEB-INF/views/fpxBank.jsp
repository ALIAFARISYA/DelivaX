<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.delivax.model.CartItem,com.delivax.util.RoleSession,java.util.*" %>
<%
  Map<String,Object> rs = RoleSession.get(request,"customer");
  if(rs==null){response.sendRedirect(request.getContextPath()+"/login");return;}
  double sub=0;
  @SuppressWarnings("unchecked")
  Map<Integer,CartItem> cart=(Map<Integer,CartItem>)rs.get("cart");
  if(cart!=null) for(CartItem ci:cart.values()) sub+=ci.getSubtotal();
  double disc=0; String dtype=(String)rs.get("discountType");
  Object dobj=rs.get("discount");
  if(dobj instanceof Number) disc=((Number)dobj).doubleValue();
  double delfee="delivery".equals(dtype)?Math.max(0,3.0-disc):3.0;
  double voff="delivery".equals(dtype)?0:disc;
  double total=Math.max(0,sub-voff+delfee);
  String ctx=request.getContextPath();
  String refNum="FPX"+System.currentTimeMillis();
  String custName=(String)rs.get("fpxCustomerName"); if(custName==null) custName="";
%>
<!DOCTYPE html><html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FPX – Select Bank</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:linear-gradient(135deg,#1e3a8a,#2d6cdf);
  min-height:100vh;display:flex;flex-direction:column;align-items:center;
  justify-content:center;padding:16px}
.container{background:#fff;width:100%;max-width:420px;border-radius:18px;
  overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,.35)}
/* header */
.hdr{background:linear-gradient(135deg,#1a5f7a,#0e7490);color:#fff;padding:18px 20px;text-align:center}
.hdr-top{display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:4px}
.fpx-badge{background:rgba(255,255,255,.18);border:1.5px solid rgba(255,255,255,.35);
  border-radius:8px;padding:5px 12px;font-size:16px;font-weight:900;letter-spacing:2px}
.hdr h2{font-size:17px;font-weight:900}
.hdr p{font-size:11px;opacity:.8;margin-top:2px}
/* timer */
.timer-bar{background:#fff3cd;padding:9px;text-align:center;border-bottom:2px solid #ffc107}
.timer-lbl{font-size:9px;color:#856404;text-transform:uppercase;letter-spacing:.5px}
.timer-num{font-size:26px;font-weight:900;color:#dc3545;font-family:monospace}
/* body */
.body{padding:14px}
/* txn box */
.txn{background:#f8faff;border-radius:9px;padding:11px;margin-bottom:12px}
.txn-row{display:flex;justify-content:space-between;padding:4px 0;
  border-bottom:1px solid #f0f4fb;font-size:11px}
.txn-row:last-child{border:none}
.txn-lbl{color:#6b7a9a;font-weight:600}
.txn-val{font-weight:800;color:#1e40af}
.amt-row{background:linear-gradient(135deg,#1e40af,#0e7490);color:#fff;
  border-radius:8px;padding:10px 12px;display:flex;justify-content:space-between;
  font-weight:900;font-size:14px;margin-top:8px}
/* bank section */
.sec-title{font-size:12px;font-weight:800;color:#1a5f7a;margin:12px 0 8px;
  display:flex;align-items:center;gap:6px;border-left:3px solid #0e7490;padding-left:9px}
/* BANK GRID — 2 columns */
.bank-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px}
.bank-opt{display:flex;align-items:center;padding:9px 10px;
  border:2px solid #e2e8f0;border-radius:10px;cursor:pointer;
  transition:all .15s;background:#fff;position:relative}
.bank-opt:hover{border-color:#0e7490;transform:translateY(-1px);box-shadow:0 4px 12px rgba(14,116,144,.15)}
.bank-opt.sel{border-color:#0e7490;background:#f0f9ff}
/* bank logo box — coloured with text */
.bank-logo-box{width:44px;height:44px;border-radius:8px;margin-right:8px;
  flex-shrink:0;display:flex;flex-direction:column;align-items:center;
  justify-content:center;font-weight:900;line-height:1;overflow:hidden}
.bank-info{flex:1;min-width:0}
.bank-name{font-size:11px;font-weight:800;color:#1a5f7a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bank-type{font-size:9px;color:#9ca3af}
.bank-chk{width:17px;height:17px;border:2px solid #cbd5e0;border-radius:50%;
  flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:900}
.bank-opt.sel .bank-chk{background:#0e7490;border-color:#0e7490;color:#fff}
/* terms */
.terms{background:#f0f9ff;border-radius:8px;padding:8px;font-size:10px;color:#6b7a9a;
  text-align:center;margin-bottom:10px}
/* warn */
.warn{background:#fef2f2;border:1px solid #fecaca;color:#dc2626;border-radius:7px;
  padding:7px 10px;font-size:11px;font-weight:600;display:none;margin-bottom:8px}
.warn.show{display:block}
/* buttons */
.btns{display:flex;gap:8px}
.btn{flex:1;padding:11px;border:none;border-radius:9px;font-size:12px;font-weight:800;cursor:pointer}
.btn-cancel{background:#e9ecef;color:#6b7a9a}
.btn-proceed{background:linear-gradient(135deg,#1e40af,#0e7490);color:#fff}
.btn-proceed:disabled{opacity:.5;cursor:not-allowed}
/* loading */
.loading{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100;align-items:center;justify-content:center}
.loading.show{display:flex}
.loading-box{background:#fff;border-radius:14px;padding:26px 22px;text-align:center}
.spinner{width:40px;height:40px;border:4px solid #e2e8f0;border-top-color:#0e7490;
  border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 10px}
@keyframes spin{to{transform:rotate(360deg)}}
.loading-box p{font-size:12px;font-weight:600;color:#374151}
.loading-box p.sub{font-size:10px;color:#9ca3af;margin-top:3px}
</style>
</head>
<body>
<div class="container">
  <div class="hdr">
    <div class="hdr-top">
      <div class="fpx-badge">FPX</div>
      <h2>Online Banking</h2>
    </div>
    <p>Secure payment via Financial Process Exchange Malaysia</p>
  </div>
  <div class="timer-bar">
    <div class="timer-lbl">Time remaining to complete payment</div>
    <div class="timer-num" id="timer">10:00</div>
  </div>
  <div class="body">
    <div class="txn">
      <div class="txn-row"><span class="txn-lbl">Order For</span><span class="txn-val"><%= custName %></span></div>
      <div class="txn-row"><span class="txn-lbl">Reference</span><span class="txn-val"><%= refNum %></span></div>
      <div class="txn-row"><span class="txn-lbl">Merchant</span><span class="txn-val">DelivaX Elite Sdn Bhd</span></div>
      <div class="txn-row"><span class="txn-lbl">Date & Time</span><span class="txn-val" id="dt"></span></div>
      <div class="amt-row"><span>💰 Total Amount</span><span>RM <%= String.format("%.2f",total) %></span></div>
    </div>
    <div class="sec-title">🏦 Select Your Bank</div>
    <div class="bank-grid" id="bankGrid"></div>
    <div class="terms">🔒 128-bit SSL Encrypted · By proceeding you agree to FPX Terms & Conditions</div>
    <div class="warn" id="warn">Please select a bank to continue.</div>
    <div class="btns">
      <button class="btn btn-cancel" onclick="cancelPayment()">✕ Cancel</button>
      <button class="btn btn-proceed" id="proceedBtn" onclick="proceed()" disabled>🔒 Proceed to Pay</button>
    </div>
  </div>
</div>
<div class="loading" id="loading">
  <div class="loading-box">
    <div class="spinner"></div>
    <p>Connecting to bank...</p>
    <p class="sub">Please do not close this window</p>
  </div>
</div>

<script>
const CTX = '<%= ctx %>';

// Malaysian banks with real brand colors and styled text logos
const BANKS = [
  {
    code:'MAYBANK', name:'Maybank', short:'MAY',
    bg:'#f5e642', fg:'#000', accent:'#f5e642',
    border:'#d4c800', desc:'Maybank2u'
  },
  {
    code:'CIMB', name:'CIMB Bank', short:'CIMB',
    bg:'#c0392b', fg:'#fff', accent:'#e74c3c',
    border:'#a93226', desc:'CIMB Clicks'
  },
  {
    code:'PUBLIC', name:'Public Bank', short:'PBB',
    bg:'#1a5276', fg:'#fff', accent:'#2980b9',
    border:'#154360', desc:'PBe'
  },
  {
    code:'RHB', name:'RHB Bank', short:'RHB',
    bg:'#e74c3c', fg:'#fff', accent:'#c0392b',
    border:'#a93226', desc:'RHB Now'
  },
  {
    code:'HONGLEONG', name:'Hong Leong Bank', short:'HLB',
    bg:'#1e3a8a', fg:'#fff', accent:'#2563eb',
    border:'#1e3a8a', desc:'HLB Connect'
  },
  {
    code:'AMBANK', name:'AmBank', short:'AMB',
    bg:'#e67e22', fg:'#fff', accent:'#d35400',
    border:'#ca6f1e', desc:'AmOnline'
  },
  {
    code:'BANKISLAM', name:'Bank Islam', short:'BIMB',
    bg:'#1d6a3a', fg:'#fff', accent:'#27ae60',
    border:'#196f3d', desc:'BIS'
  },
  {
    code:'BANKRAKYAT', name:'Bank Rakyat', short:'BR',
    bg:'#6c3483', fg:'#fff', accent:'#8e44ad',
    border:'#6c3483', desc:'i-Rakyat'
  },
  {
    code:'AFFIN', name:'Affin Bank', short:'AFF',
    bg:'#117a65', fg:'#fff', accent:'#148f77',
    border:'#0e6655', desc:'Affin Online'
  },
  {
    code:'ALLIANCE', name:'Alliance Bank', short:'ALB',
    bg:'#1f618d', fg:'#fff', accent:'#2874a6',
    border:'#1a5276', desc:'AllianceOnline'
  }
];

let selected = null, timeLeft = 600, expired = false;

document.getElementById('dt').textContent = new Date().toLocaleString('en-MY');

// Build bank grid with styled logo boxes
document.getElementById('bankGrid').innerHTML = BANKS.map(function(b){
  var fs = b.short.length > 3 ? '8' : '10';
  return '<div class="bank-opt" id="bo-'+b.code+'" onclick="pick(\''+b.code+'\',\''+b.name+'\',this)">'
    + '<div class="bank-logo-box" style="background:'+b.bg+';border:1.5px solid '+b.border+'">'
    + '<span style="color:'+b.fg+';font-size:'+fs+'px;font-weight:900;letter-spacing:-.2px">'+b.short+'</span>'
    + '</div>'
    + '<div class="bank-info">'
    + '<div class="bank-name">'+b.name+'</div>'
    + '<div class="bank-type">'+b.desc+'</div>'
    + '</div>'
    + '<div class="bank-chk" id="bc-'+b.code+'"></div>'
    + '</div>';
}).join('');

// Timer
const timerEl = document.getElementById('timer');
const iv = setInterval(()=>{
  if(timeLeft<=0){
    clearInterval(iv); expired=true;
    timerEl.textContent='00:00'; timerEl.style.color='#dc2626';
    document.getElementById('proceedBtn').disabled=true;
    document.getElementById('warn').textContent='Session expired. Please go back and try again.';
    document.getElementById('warn').classList.add('show'); return;
  }
  timeLeft--;
  const m=Math.floor(timeLeft/60),s=timeLeft%60;
  timerEl.textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;
  if(timeLeft<=60) timerEl.style.color='#dc2626';
},1000);

function pick(code,name,el){
  selected={code,name};
  document.querySelectorAll('.bank-opt').forEach(b=>b.classList.remove('sel'));
  document.querySelectorAll('[id^="bc-"]').forEach(c=>c.textContent='');
  el.classList.add('sel');
  document.getElementById('bc-'+code).textContent='✓';
  document.getElementById('proceedBtn').disabled=false;
  document.getElementById('warn').classList.remove('show');
}

function proceed(){
  if(!selected||expired) return;
  document.getElementById('loading').classList.add('show');
  const f=document.createElement('form'); f.method='post'; f.action=CTX+'/fpx';
  const add=(n,v)=>{const i=document.createElement('input');i.type='hidden';i.name=n;i.value=v;f.appendChild(i);};
  add('step','bank'); add('bankCode',selected.code); add('bankName',selected.name);
  document.body.appendChild(f); f.submit();
}

function cancelPayment(){
  if(confirm('Cancel this FPX payment?')) window.location.href=CTX+'/checkout';
}
</script>
</body></html>
