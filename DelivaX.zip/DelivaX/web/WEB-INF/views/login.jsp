<%@ page contentType="text/html;charset=UTF-8" %>
<%
  String success = (String) session.getAttribute("regSuccess");
  if (success != null) session.removeAttribute("regSuccess");
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DelivaX – Login</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{
  font-family:'Segoe UI',sans-serif;
  min-height:100vh;
  background:linear-gradient(160deg,#0f172a 0%,#1e3a8a 55%,#1e40af 100%);
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  padding:24px 16px;
}

/* BRAND */
.brand{text-align:center;margin-bottom:26px}
.brand-logo{font-size:36px;font-weight:900;color:#fff;letter-spacing:-1.5px;line-height:1}
.brand-logo span{color:#fbbf24}
.brand-tag{font-size:13px;color:rgba(255,255,255,.55);margin-top:7px}

/* CARD */
.card{
  background:#fff;border-radius:20px;
  width:100%;max-width:370px;
  box-shadow:0 24px 80px rgba(0,0,0,.4);
  overflow:hidden;
}
.card-hdr{
  background:linear-gradient(135deg,#1e3a8a,#2d6cdf);
  padding:20px 22px 18px;color:#fff;
}
.card-hdr h2{font-size:19px;font-weight:800;margin-bottom:2px}
.card-hdr p{font-size:12px;opacity:.7}
.card-body{padding:20px 22px 22px}

/* ROLE */
.roles{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:18px}
.rl{
  border:2px solid #e2e8f0;border-radius:10px;
  padding:10px 4px;cursor:pointer;text-align:center;
  font-size:11px;font-weight:700;color:#64748b;
  background:#f8faff;transition:all .15s;
}
.rl .ico{font-size:22px;display:block;margin-bottom:3px}
.rl.on{border-color:#2d6cdf;background:#eff6ff;color:#2d6cdf}
.rl:hover:not(.on){border-color:#93c5fd}

/* FORM */
.field{margin-bottom:13px}
.fl{display:block;font-size:10px;font-weight:800;text-transform:uppercase;
  letter-spacing:.7px;color:#94a3b8;margin-bottom:4px}
.fi{
  width:100%;padding:11px 13px;
  border:1.5px solid #e2e8f0;border-radius:9px;
  font-size:14px;font-family:inherit;color:#1e2d50;
  outline:none;transition:border .15s,box-shadow .15s;
}
.fi:focus{border-color:#2d6cdf;box-shadow:0 0 0 3px rgba(45,108,223,.1)}

/* BUTTON */
.btn{
  width:100%;padding:13px;margin-top:4px;
  background:linear-gradient(135deg,#2d6cdf,#1e3a8a);
  color:#fff;border:none;border-radius:10px;
  font-size:14px;font-weight:800;cursor:pointer;
  transition:opacity .15s;letter-spacing:.2px;
}
.btn:hover{opacity:.92}

/* ALERTS */
.alert{
  padding:10px 13px;border-radius:9px;
  font-size:12px;font-weight:600;
  margin-bottom:16px;line-height:1.5;
  display:flex;align-items:flex-start;gap:8px;
}
.alert-err{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
.alert-ok {background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0}

/* FOOTER */
.card-ftr{
  border-top:1px solid #f1f5f9;
  padding:14px 22px;
  display:flex;flex-direction:column;gap:10px;
  text-align:center;
}
.ftr-link{font-size:12px;color:#64748b}
.ftr-link a{color:#2d6cdf;font-weight:700;text-decoration:none}
.ftr-link a:hover{text-decoration:underline}
.sep{display:flex;align-items:center;gap:8px;color:#cbd5e1;font-size:11px}
.sep::before,.sep::after{content:'';flex:1;height:1px;background:#e2e8f0}
</style>
</head>
<body>

<div class="brand">
  <div class="brand-logo">Deliva<span>X</span></div>
  <div class="brand-tag">🍢 Arabian cuisine · Delivered fresh</div>
</div>

<div class="card">
  <div class="card-hdr">
    <h2>Welcome back 👋</h2>
    <p>Sign in to continue</p>
  </div>

  <div class="card-body">
    <% String kicked = request.getParameter("kicked"); %>
<% if (success != null) { %>
    <div class="alert alert-ok">✅ <%= success %></div>
    <% } %>
    <% if ("true".equals(kicked)) { %>
    <div class="alert alert-err">⚠️ You were logged out because this account signed in elsewhere.</div>
    <% } %>
    <% if (request.getAttribute("error") != null) { %>
    <div class="alert alert-err">⚠️ ${error}</div>
    <% } %>

    <!-- Role -->
    <div class="roles">
      <div class="rl on" id="rl-customer" onclick="setRole('customer')">
        <span class="ico">🛍️</span>Customer
      </div>
      <div class="rl" id="rl-staff" onclick="setRole('staff')">
        <span class="ico">👨‍🍳</span>Kitchen
      </div>
      <div class="rl" id="rl-rider" onclick="setRole('rider')">
        <span class="ico">🛵</span>Rider
      </div>
    </div>

    <form method="post" action="${pageContext.request.contextPath}/login">
      <input type="hidden" name="role" id="role-val" value="customer">
      <div class="field">
        <label class="fl">Name</label>
        <input class="fi" name="name" placeholder="Enter your name" autocomplete="username" required>
      </div>
      <div class="field">
        <label class="fl">Password</label>
        <input class="fi" type="password" name="password" placeholder="Enter your password" required>
      </div>
      <button type="submit" class="btn">Sign In →</button>
    </form>
  </div>

  <div class="card-ftr">
    <div class="ftr-link">
      New customer? <a href="${pageContext.request.contextPath}/register">Create an account →</a>
    </div>
    <div class="sep">or</div>
    <form method="post" action="${pageContext.request.contextPath}/login" style="margin:0">
      <input type="hidden" name="action" value="guest">
      <div class="ftr-link">
        <a onclick="this.closest('form').submit()" style="color:#94a3b8">Browse menu as guest</a>
      </div>
    </form>
  </div>
</div>

<script>
function setRole(r){
  document.getElementById('role-val').value = r;
  ['customer','staff','rider'].forEach(x =>
    document.getElementById('rl-'+x).classList.toggle('on', x===r)
  );
}
</script>
</body>
</html>
