<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.delivax.model.*,com.delivax.util.RoleSession,java.util.*" %>
<%
  // Items and categories set by MenuController
  @SuppressWarnings("unchecked")
  List<MenuItem> items = (List<MenuItem>) request.getAttribute("items");
  @SuppressWarnings("unchecked")
  List<String> categories = (List<String>) request.getAttribute("categories");
  String activeCat = request.getAttribute("activeCat") != null ? (String)request.getAttribute("activeCat") : "All";
  String searchQ   = request.getAttribute("search")    != null ? (String)request.getAttribute("search")    : "";
  if (items == null) items = new java.util.ArrayList<>();
  if (categories == null) categories = new java.util.ArrayList<>();

  // Session info set by MenuController — safe, never null
  String sessionUser = (String) request.getAttribute("sessionUser");
  String sessionRole = request.getAttribute("sessionRole") != null
      ? (String) request.getAttribute("sessionRole") : "guest";

  // Cart from customer role session (null-safe)
  Map<String,Object> custSession = RoleSession.get(request, "customer");
  @SuppressWarnings("unchecked")
  Map<Integer,CartItem> cart = (custSession != null)
      ? (Map<Integer,CartItem>) custSession.get("cart") : null;
  int cartCount=0; double cartTotal=0;
  if(cart!=null) for(CartItem ci:cart.values()){cartCount+=ci.getQty();cartTotal+=ci.getSubtotal();}

  String ctx = request.getContextPath();
%>
<!DOCTYPE html><html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DelivaX – Menu</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:#f1f5f9;color:#1e2d50;font-size:13px;padding-bottom:76px;max-width:480px;margin:0 auto}
.tb{background:linear-gradient(135deg,#1e40af,#2d6cdf);color:#fff;height:52px;padding:0 12px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:200;box-shadow:0 3px 14px rgba(30,64,175,.4)}
.tb-logo{font-size:19px;font-weight:900;letter-spacing:-.4px}.tb-logo span{color:#fbbf24}
.tb-user{font-size:10px;opacity:.7;margin-top:2px}
.tb-btn{background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.26);color:#fff;border-radius:16px;padding:5px 12px;font-size:12px;font-weight:700;text-decoration:none}
.ps{display:flex;gap:8px;overflow-x:auto;padding:9px 10px 3px;scrollbar-width:none}
.ps::-webkit-scrollbar{display:none}
.pc{flex-shrink:0;min-width:155px;border-radius:9px;padding:9px 11px;color:#fff}
.pc1{background:linear-gradient(135deg,#f97316,#c2410c)}.pc2{background:linear-gradient(135deg,#2563eb,#1e40af)}.pc3{background:linear-gradient(135deg,#7c3aed,#5b21b6)}
.pc-tag{font-size:8px;font-weight:800;letter-spacing:1px;opacity:.8;text-transform:uppercase}
.pc-title{font-size:12px;font-weight:800;margin:3px 0 5px;line-height:1.3}
.pc-save{background:rgba(255,255,255,.22);border-radius:6px;padding:2px 7px;font-size:10px;font-weight:800}
.sw{padding:8px 10px 3px;position:relative}
.sw form{position:relative}
.si{position:absolute;left:11px;top:50%;transform:translateY(-50%);font-size:14px;pointer-events:none;z-index:1}
.sf{width:100%;padding:9px 12px 9px 34px;border:1.5px solid #e2e8f0;border-radius:20px;font-size:13px;background:#fff;outline:none}
.sf:focus{border-color:#1e40af}
.cats{display:flex;gap:6px;overflow-x:auto;padding:6px 10px;scrollbar-width:none}
.cats::-webkit-scrollbar{display:none}
.cat{white-space:nowrap;border:1.5px solid #e2e8f0;border-radius:16px;padding:5px 13px;font-size:12px;font-weight:700;cursor:pointer;text-decoration:none;color:#64748b;background:#fff}
.cat.on{background:#1e40af;border-color:#1e40af;color:#fff}
.sec{font-size:13px;font-weight:800;color:#374151;padding:5px 10px 4px;display:flex;align-items:center;gap:5px}
.sec-ct{font-size:10px;font-weight:600;color:#9ca3af}
.mlist{padding:0 10px}
.mc{background:#fff;border-radius:10px;border:1px solid #e2e8f0;display:flex;align-items:stretch;margin-bottom:8px;overflow:hidden;box-shadow:0 1px 5px rgba(0,0,0,.07);cursor:pointer;transition:box-shadow .15s;min-height:95px}
.mc:hover{box-shadow:0 4px 14px rgba(30,64,175,.14)}
.mc-img{width:95px;flex-shrink:0;position:relative;overflow:hidden;background:#f1f5f9}
.mc-img img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .3s}
.mc:hover .mc-img img{transform:scale(1.06)}
.dp{position:absolute;top:5px;left:5px;background:#f97316;color:#fff;font-size:8px;font-weight:800;padding:2px 6px;border-radius:5px;text-transform:uppercase}
.ap{position:absolute;bottom:5px;left:5px;background:rgba(30,64,175,.85);color:#fff;font-size:8px;font-weight:700;padding:2px 6px;border-radius:5px}
.mc-body{flex:1;padding:9px 10px;display:flex;flex-direction:column;justify-content:space-between;min-width:0}
.mc-name{font-size:13px;font-weight:800;color:#1e2d50;line-height:1.25;margin-bottom:3px}
.mc-desc{font-size:11px;color:#9ca3af;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.mc-foot{display:flex;align-items:center;justify-content:space-between;margin-top:6px;gap:6px}
.mc-price{font-size:15px;font-weight:900;color:#1e40af;line-height:1}
.mc-psub{font-size:9px;color:#9ca3af;font-weight:500;display:block;margin-top:1px}
.add-btn{width:32px;height:32px;flex-shrink:0;background:linear-gradient(135deg,#1e40af,#2563eb);color:#fff;border:none;border-radius:8px;font-size:20px;font-weight:900;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 7px rgba(30,64,175,.3);transition:all .15s;line-height:1}
.add-btn:hover{transform:scale(1.1)}
.add-btn.gr{background:linear-gradient(135deg,#94a3b8,#64748b);box-shadow:none}
.add-btn.gr:hover{transform:none}
.cf{position:fixed;bottom:0;left:0;right:0;max-width:480px;margin:0 auto;background:linear-gradient(135deg,#1e40af,#2563eb);color:#fff;padding:10px 14px;display:flex;align-items:center;gap:10px;box-shadow:0 -3px 16px rgba(30,64,175,.4);z-index:100}
.cf-ic{font-size:22px}.cf-inf{flex:1}
.cf-ct{font-size:13px;font-weight:800}.cf-am{font-size:11px;opacity:.8}
.cf-btn{background:#fff;color:#1e40af;border:none;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:800;cursor:pointer;text-decoration:none;white-space:nowrap}
.empty{text-align:center;padding:44px 16px;color:#9ca3af}
.ov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:500;align-items:flex-end;justify-content:center}
.ov.open{display:flex}
.sh{background:#fff;border-radius:20px 20px 0 0;width:100%;max-width:480px;max-height:88vh;overflow-y:auto}
.sh-handle{width:36px;height:4px;background:#e2e8f0;border-radius:2px;margin:12px auto 0}
.sh-img{width:100%;height:195px;object-fit:cover;display:block;margin-top:8px}
.sh-info{padding:10px 14px 8px;border-bottom:1px solid #f1f5f9}
.sh-name{font-size:17px;font-weight:900;color:#1e2d50;margin-bottom:2px}
.sh-desc{font-size:12px;color:#6b7a9a;line-height:1.45;margin-bottom:5px}
.sh-base{font-size:14px;font-weight:900;color:#1e40af}
.sh-body{padding:10px 14px 4px}
.al-lbl{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.6px;color:#9ca3af;margin-bottom:7px}
.ar{display:flex;align-items:center;justify-content:space-between;padding:9px 10px;border-radius:9px;margin-bottom:5px;border:1.5px solid #e2e8f0;background:#f8faff;cursor:pointer;transition:all .15s}
.ar:hover{border-color:#93c5fd}.ar.sel{border-color:#1e40af;background:#eff6ff}
.ar-left{display:flex;align-items:center;gap:9px}
.ar-chk{width:20px;height:20px;border-radius:50%;border:2px solid #cbd5e1;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:900;flex-shrink:0;transition:all .15s}
.ar.sel .ar-chk{background:#1e40af;border-color:#1e40af;color:#fff}
.ar-name{font-size:13px;font-weight:700;color:#1e2d50}
.ar-price{font-size:12px;font-weight:800;color:#1e40af;white-space:nowrap}
.no-addon{font-size:12px;color:#9ca3af;text-align:center;padding:12px;font-style:italic;background:#f8faff;border-radius:9px}
.sh-foot{padding:10px 14px 24px;border-top:1px solid #f1f5f9;background:#fff;position:sticky;bottom:0}
.tot-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
.tot-lbl{font-size:12px;color:#6b7a9a}.tot-val{font-size:19px;font-weight:900;color:#1e40af}
.btn-row{display:flex;gap:8px}
.btn-c{flex:1;padding:12px;background:#f1f5f9;color:#64748b;border:none;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer}
.btn-a{flex:2;padding:12px;background:linear-gradient(135deg,#1e40af,#2563eb);color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:800;cursor:pointer}
</style>
</head>
<body>
<div class="tb">
  <div>
    <div class="tb-logo">Deliva<span>X</span></div>
    <div class="tb-user"><% if(sessionUser!=null){ %>Hello, <%= sessionUser %> 👋<% }else{ %>Browse our menu<% } %></div>
  </div>
  <a href="<%= ctx %>/logout?role=<%= sessionRole %>" class="tb-btn">Logout</a>
</div>
<div class="ps">
  <div class="pc pc1"><div class="pc-tag">🔥 Combo</div><div class="pc-title">Chicken Mandi + Mint Tea</div><span class="pc-save">Save RM3</span></div>
  <div class="pc pc2"><div class="pc-tag">⭐ Weekend</div><div class="pc-title">Lamb Kabsa + Coffee</div><span class="pc-save">Save RM3</span></div>
  <div class="pc pc3"><div class="pc-tag">💚 Value</div><div class="pc-title">Falafel + Soft Drink</div><span class="pc-save">Save RM1</span></div>
</div>
<div class="sw">
  <form method="get" action="<%= ctx %>/menu">
    <span class="si">🔍</span>
    <input class="sf" name="search" placeholder="Search dishes..." value="<%= searchQ %>">
  </form>
</div>
<div class="cats">
  <% for(String c:categories){ %><a class="cat <%= c.equals(activeCat)?"on":"" %>" href="<%= ctx %>/menu?cat=<%= c %>"><%= c %></a><% } %>
</div>
<div class="sec">
  <% if("All".equals(activeCat)){ %>🍽️ All Dishes<% }else{ %><%= activeCat %><% } %>
  <span class="sec-ct">(<%= items.size() %> items)</span>
</div>
<div class="mlist">
<% if(items.isEmpty()){ %>
  <div class="empty"><div style="font-size:40px;margin-bottom:8px">🔍</div><p style="font-weight:600;font-size:13px">No dishes found.</p></div>
<% }else{ for(MenuItem item:items){ %>
  <div class="mc" onclick="openModal(<%= item.getId() %>)">
    <div class="mc-img">
      <img src="<%= item.getImgUrl() %>" alt="<%= item.getName() %>" loading="lazy">
      <% if(item.isDeal()){ %><div class="dp">🔥 Deal</div><% } %>
      <% if(item.getAddons()!=null&&!item.getAddons().isEmpty()){ %><div class="ap">+<%= item.getAddons().size() %> add-ons</div><% } %>
    </div>
    <div class="mc-body">
      <div><div class="mc-name"><%= item.getName() %></div><div class="mc-desc"><%= item.getDesc() %></div></div>
      <div class="mc-foot">
        <div><div class="mc-price">RM<%= String.format("%.2f",item.getPrice()) %></div><span class="mc-psub">per serving</span></div>
        <% if("customer".equals(sessionRole)){ %>
        <button class="add-btn" onclick="event.stopPropagation();openModal(<%= item.getId() %>)">+</button>
        <% }else{ %>
        <button class="add-btn gr" onclick="event.stopPropagation();alert('Please login as Customer to order.')">+</button>
        <% } %>
      </div>
    </div>
  </div>
<% }} %>
</div>
<% if(cartCount>0&&"customer".equals(sessionRole)){ %>
<div class="cf">
  <div class="cf-ic">🛒</div>
  <div class="cf-inf"><div class="cf-ct"><%= cartCount %> item<%= cartCount!=1?"s":"" %></div><div class="cf-am">RM<%= String.format("%.2f",cartTotal) %></div></div>
  <a href="<%= ctx %>/cart" class="cf-btn">View Cart →</a>
</div>
<% } %>
<div class="ov" id="ov" onclick="if(event.target===this)closeModal()">
  <div class="sh">
    <div class="sh-handle"></div>
    <img class="sh-img" id="sh-img" src="" alt="">
    <div class="sh-info"><div class="sh-name" id="sh-name"></div><div class="sh-desc" id="sh-desc"></div><div class="sh-base" id="sh-base"></div></div>
    <div class="sh-body"><div class="al-lbl">Customise your order</div><div id="sh-list"></div></div>
    <div class="sh-foot">
      <div class="tot-row"><span class="tot-lbl">Item Total</span><span class="tot-val" id="sh-total">RM 0.00</span></div>
      <div class="btn-row"><button class="btn-c" onclick="closeModal()">Cancel</button><button class="btn-a" id="sh-add">Add to Cart 🛒</button></div>
    </div>
  </div>
</div>
<script>
const CTX='<%= ctx %>';const ROLE='<%= sessionRole %>';const MENU={};
<% for(MenuItem m:items){
  String jName=m.getName().replace("\\","\\\\").replace("\"","\\\"").replace("'","\\'");
  String jDesc=(m.getDesc()!=null?m.getDesc():"").replace("\\","\\\\").replace("\"","\\\"").replace("'","\\'").replace("\n","");
  String jImg=(m.getImgUrl()!=null?m.getImgUrl():""); %>
MENU[<%= m.getId() %>]={id:<%= m.getId() %>,name:"<%= jName %>",price:<%= m.getPrice() %>,img:"<%= jImg %>",desc:"<%= jDesc %>",addons:[
<% List<Addon> addons=m.getAddons(); if(addons!=null){for(int ai=0;ai<addons.size();ai++){Addon a=addons.get(ai);String aName=a.getName().replace("\\","\\\\").replace("\"","\\\"").replace("'","\\'"); %>
{id:"<%= a.getId() %>",name:"<%= aName %>",price:<%= a.getPrice() %>}<%= ai<addons.size()-1?",":"" %>
<% }} %>]};
<% } %>
let cur=null,sel={};
function openModal(id){if(ROLE!=='customer'){alert('Please login as Customer to order.');return;}const m=MENU[id];if(!m)return;cur=m;sel={};document.getElementById('sh-img').src=m.img;document.getElementById('sh-name').textContent=m.name;document.getElementById('sh-desc').textContent=m.desc;document.getElementById('sh-base').textContent='Base price: RM '+m.price.toFixed(2);let html='';if(m.addons&&m.addons.length>0){m.addons.forEach(function(a){html+='<div class="ar" id="ar-'+a.id+'" onclick="tog(\''+a.id+'\',\''+a.name.replace(/'/g,"\\'")+'\',' +a.price+')"><div class="ar-left"><div class="ar-chk" id="ac-'+a.id+'"></div><span class="ar-name">'+a.name+'</span></div><span class="ar-price">+RM '+a.price.toFixed(2)+'</span></div>';});}else{html='<div class="no-addon">No add-ons available.</div>';}document.getElementById('sh-list').innerHTML=html;recalc();document.getElementById('ov').classList.add('open');}
function tog(id,name,price){if(sel[id])delete sel[id];else sel[id]={name:name,price:price};var r=document.getElementById('ar-'+id),c=document.getElementById('ac-'+id);if(sel[id]){r.classList.add('sel');c.textContent='✓';}else{r.classList.remove('sel');c.textContent='';}recalc();}
function recalc(){if(!cur)return;var ex=0;Object.keys(sel).forEach(function(k){ex+=sel[k].price;});document.getElementById('sh-total').textContent='RM '+(cur.price+ex).toFixed(2);}
document.getElementById('sh-add').onclick=function(){if(!cur)return;var f=document.createElement('form');f.method='post';f.action=CTX+'/cart';function add(n,v){var i=document.createElement('input');i.type='hidden';i.name=n;i.value=v;f.appendChild(i);}add('action','add');add('id',cur.id);add('from','menu');Object.keys(sel).forEach(function(id){add('addon_'+id,'on');});document.body.appendChild(f);f.submit();};
function closeModal(){document.getElementById('ov').classList.remove('open');cur=null;sel={};}
</script>
</body></html>
