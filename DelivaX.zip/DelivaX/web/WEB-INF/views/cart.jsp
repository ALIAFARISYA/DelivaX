<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.delivax.model.CartItem,com.delivax.util.RoleSession,java.util.*" %>
<%
  java.util.Map<String,Object> rs = com.delivax.util.RoleSession.get(request,"customer");
  if(rs==null) rs=new java.util.HashMap<>();
  @SuppressWarnings("unchecked")
  Map<Integer,CartItem> cart=(Map<Integer,CartItem>)rs.get("cart");
  if(cart==null) cart=new LinkedHashMap<>();
  double sub=0; int qty=0;
  for(CartItem ci:cart.values()){sub+=ci.getSubtotal();qty+=ci.getQty();}
  double disc=0; String dtype=(String)rs.get("discountType");
  Object dobj=rs.get("discount");
  if(dobj instanceof Number) disc=((Number)dobj).doubleValue();
  String voucher=(String)rs.get("voucher");
  double delfee="delivery".equals(dtype)?Math.max(0,3.0-disc):3.0;
  double voff="delivery".equals(dtype)?0:disc;
  double total=Math.max(0,sub-voff+delfee);
  int lpts=rs.get("loyaltyPts") instanceof Integer?(Integer)rs.get("loyaltyPts"):0;
  String vmsg=(String)rs.get("voucherMsg");
  if(vmsg!=null) rs.remove("voucherMsg");
  String ctx=request.getContextPath();
%>
<!DOCTYPE html><html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DelivaX – Cart</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',sans-serif;background:#f1f5f9;color:#1e2d50;font-size:13px}
/* centre everything, max 420px */
.page{max-width:420px;margin:0 auto;padding:0 0 20px}
/* topbar */
.tb{background:linear-gradient(135deg,#1e40af,#2d6cdf);color:#fff;height:48px;
  padding:0 12px;display:flex;align-items:center;justify-content:space-between;
  box-shadow:0 2px 10px rgba(30,64,175,.35);position:sticky;top:0;z-index:50}
.tb-logo{font-size:17px;font-weight:900}.tb-logo span{color:#fbbf24}
.tb-btn{background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.26);
  color:#fff;border-radius:14px;padding:4px 11px;font-size:11px;font-weight:700;text-decoration:none}
/* section header */
.sh{font-size:12px;font-weight:800;color:#374151;padding:10px 12px 6px}
/* cart item card */
.ci{background:#fff;border-radius:10px;border:1px solid #e2e8f0;
  margin:0 12px 7px;overflow:hidden}
/* top row: img | name+addon | price */
.ci-row{display:flex;align-items:center;gap:8px;padding:8px 10px}
.ci-img{width:46px;height:46px;border-radius:7px;object-fit:cover;flex-shrink:0}
.ci-mid{flex:1;min-width:0}
.ci-name{font-size:12px;font-weight:800;line-height:1.2;white-space:nowrap;
  overflow:hidden;text-overflow:ellipsis}
.ci-addon{font-size:10px;color:#7c3aed;font-weight:600;margin-top:1px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ci-base{font-size:9px;color:#9ca3af;margin-top:1px}
.ci-price{font-size:13px;font-weight:900;color:#1e40af;flex-shrink:0;white-space:nowrap}
/* bottom row: remove | qty */
.ci-bot{display:flex;align-items:center;justify-content:space-between;
  padding:5px 10px 7px;border-top:1px solid #f1f5f9}
.rm{background:none;border:none;color:#ef4444;font-size:11px;
  font-weight:700;cursor:pointer;padding:2px 6px}
.rm:hover{background:#fef2f2;border-radius:5px}
.qc{display:flex;align-items:center;gap:6px}
.qb{width:24px;height:24px;border-radius:50%;border:none;font-size:14px;font-weight:900;
  cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1}
.qb.m{background:#f1f5f9;color:#374151}.qb.p{background:#1e40af;color:#fff}
.qn{font-size:13px;font-weight:900;min-width:16px;text-align:center}
/* add more */
.more{display:block;text-align:center;color:#1e40af;font-size:11px;
  font-weight:700;padding:6px;text-decoration:none}
/* summary box */
.sum{background:#fff;border-radius:10px;border:1px solid #e2e8f0;
  margin:0 12px 7px;padding:10px 12px}
.sr{display:flex;justify-content:space-between;align-items:center;
  padding:3px 0;font-size:12px;font-weight:600;color:#374151}
.sr.tot{font-weight:900;font-size:14px;color:#1e40af;
  border-top:1.5px solid #e2e8f0;margin-top:5px;padding-top:6px}
.sr.sv{color:#16a34a}
/* voucher */
.vc{background:linear-gradient(135deg,#4f46e5,#7c3aed);border-radius:10px;
  padding:10px 12px;margin:0 12px 7px;color:#fff}
.vc-hdr{font-size:12px;font-weight:800;margin-bottom:1px}
.vc-sub{font-size:9px;opacity:.8;margin-bottom:7px}
.vc-row{display:flex;gap:6px}
.vc-in{flex:1;padding:7px 9px;border:none;border-radius:7px;font-size:12px;outline:none}
.vc-btn{padding:7px 12px;background:rgba(255,255,255,.25);color:#fff;
  border:none;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap}
.vc-ok{display:flex;justify-content:space-between;align-items:center;
  background:rgba(255,255,255,.18);border-radius:6px;padding:5px 9px;
  margin-top:6px;font-size:11px;font-weight:700}
.vc-rm{background:rgba(255,255,255,.22);border:none;color:#fff;
  border-radius:4px;padding:2px 7px;cursor:pointer;font-size:10px}
/* msg */
.al{padding:7px 10px;border-radius:7px;font-size:11px;font-weight:600;margin:0 12px 7px}
.al-ok{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0}
.al-err{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
/* loyalty */
.ly{background:#fff;border-radius:10px;border:2px solid #fbbf24;
  padding:10px 12px;margin:0 12px 10px}
.ly-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px}
.ly-left{}
.ly-title{font-size:12px;font-weight:800}
.ly-tier{font-size:9px;color:#9ca3af;margin-top:1px}
.ly-right{text-align:right}
.ly-pts{font-size:20px;font-weight:900;color:#f59e0b;line-height:1}
.ly-lbl{font-size:9px;color:#9ca3af}
.ly-bar{background:#e2e8f0;border-radius:3px;height:4px;overflow:hidden;margin-bottom:5px}
.ly-fill{background:linear-gradient(90deg,#fbbf24,#f59e0b);height:100%}
.ly-msg{font-size:10px;color:#92400e;background:#fef3c7;border-radius:5px;padding:5px 7px}
/* checkout btn */
.chk{display:block;margin:0 12px;padding:12px;
  background:linear-gradient(135deg,#1e40af,#2563eb);
  color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:800;
  text-align:center;text-decoration:none;cursor:pointer}
/* empty */
.empty{text-align:center;padding:44px 16px;color:#9ca3af}
.ei{font-size:40px;margin-bottom:8px}
</style>
</head>
<body>
<div class="tb">
  <div><div class="tb-logo">Deliva<span>X</span></div>
    <div style="font-size:9px;opacity:.7">Your Cart 🛒</div></div>
  <a href="<%= ctx %>/menu" class="tb-btn">← Menu</a>
</div>

<div class="page">
  <div class="sh">Your Order (<%= qty %> item<%= qty!=1?"s":"" %>)</div>

  <% if(cart.isEmpty()){ %>
  <div class="empty"><div class="ei">🛒</div>
    <p style="font-size:12px;font-weight:600">Cart is empty</p>
    <a href="<%= ctx %>/menu" class="chk" style="margin-top:14px;display:block">Browse Menu</a>
  </div>
  <% }else{ %>

  <% for(CartItem ci:cart.values()){ %>
  <div class="ci">
    <div class="ci-row">
      <img class="ci-img" src="<%= ci.getImgUrl() %>" alt="">
      <div class="ci-mid">
        <div class="ci-name"><%= ci.getName() %></div>
        <% if(ci.getSelectedAddons()!=null&&!ci.getSelectedAddons().isEmpty()){ %>
        <div class="ci-addon">➕ <%= ci.getAddonsDisplay() %></div>
        <% } %>
        <div class="ci-base">Base RM<%= String.format("%.2f",ci.getPrice()) %>
          <% if(ci.getUnitPrice()>ci.getPrice()){ %> · Unit RM<%= String.format("%.2f",ci.getUnitPrice()) %><% } %>
        </div>
      </div>
      <div class="ci-price">RM<%= String.format("%.2f",ci.getSubtotal()) %></div>
    </div>
    <div class="ci-bot">
      <form method="post" action="<%= ctx %>/cart" style="display:contents">
        <input type="hidden" name="action" value="remove">
        <input type="hidden" name="id" value="<%= ci.getId() %>">
        <button type="submit" class="rm">✕ Remove</button>
      </form>
      <div class="qc">
        <form method="post" action="<%= ctx %>/cart" style="display:contents">
          <input type="hidden" name="action" value="dec">
          <input type="hidden" name="id" value="<%= ci.getId() %>">
          <button type="submit" class="qb m">−</button>
        </form>
        <span class="qn"><%= ci.getQty() %></span>
        <form method="post" action="<%= ctx %>/cart" style="display:contents">
          <input type="hidden" name="action" value="inc">
          <input type="hidden" name="id" value="<%= ci.getId() %>">
          <button type="submit" class="qb p">+</button>
        </form>
      </div>
    </div>
  </div>
  <% } %>

  <a href="<%= ctx %>/menu" class="more">+ Add more dishes</a>

  <div class="sum">
    <div class="sr"><span>Subtotal</span><span>RM<%= String.format("%.2f",sub) %></span></div>
    <% if(voff>0){ %>
    <div class="sr sv"><span>Voucher (<%= voucher %>)</span><span>−RM<%= String.format("%.2f",voff) %></span></div>
    <% } %>
    <% if("delivery".equals(dtype)){ %>
    <div class="sr sv"><span>Free delivery</span><span>−RM3.00</span></div>
    <% } %>
    <div class="sr"><span>Delivery fee</span><span>RM<%= String.format("%.2f",delfee) %></span></div>
    <div class="sr tot"><span>Total Payable</span><span>RM<%= String.format("%.2f",total) %></span></div>
  </div>

  <% if(vmsg!=null){ boolean ok=vmsg.startsWith("✅"); %>
  <div class="al <%= ok?"al-ok":"al-err" %>"><%= vmsg %></div>
  <% } %>

  <div class="vc">
    <div class="vc-hdr">🎟️ Voucher Code</div>
    <div class="vc-sub">WELCOME10 · SAVE15 · FLAT8 · FREEDEL</div>
    <form method="post" action="<%= ctx %>/cart">
      <input type="hidden" name="action" value="voucher">
      <div class="vc-row">
        <input class="vc-in" name="code" placeholder="Enter code">
        <button type="submit" class="vc-btn">Apply</button>
      </div>
    </form>
    <% if(voucher!=null){ %>
    <div class="vc-ok">
      <span>✅ <%= voucher %> applied</span>
      <form method="post" action="<%= ctx %>/cart" style="display:inline">
        <input type="hidden" name="action" value="removevoucher">
        <button type="submit" class="vc-rm">✕</button>
      </form>
    </div>
    <% } %>
  </div>

  <div class="ly">
    <div class="ly-top">
      <div class="ly-left">
        <div class="ly-title">⭐ Loyalty Points</div>
        <div class="ly-tier"><%= lpts>=1000?"Platinum 🏆":lpts>=500?"Gold ✨":"Silver" %> Member</div>
      </div>
      <div class="ly-right">
        <div class="ly-pts"><%= lpts %></div>
        <div class="ly-lbl">points</div>
      </div>
    </div>
    <div class="ly-bar"><div class="ly-fill" style="width:<%= Math.min(100,(lpts%500)/5.0) %>%"></div></div>
    <div class="ly-msg">💝
      <% if(lpts<500){ %>Earn <%= 500-lpts %> more pts → Gold
      <% }else if(lpts<1000){ %>Earn <%= 1000-lpts %> more pts → Platinum
      <% }else{ %>Maximum tier reached! 🏆<% } %>
    </div>
  </div>

  <a href="<%= ctx %>/checkout" class="chk">Proceed to Checkout →</a>
  <% } %>
</div>
</body></html>
