-- ============================================================
--  DelivaX — Run in phpMyAdmin
--  1. New → name: delivax → Create
--  2. Click delivax → Import → choose this file → Go
-- ============================================================
CREATE DATABASE IF NOT EXISTS delivax CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE delivax;

CREATE TABLE IF NOT EXISTS users (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(100)  NOT NULL,
    password       VARCHAR(255)  NOT NULL,
    role           ENUM('customer','staff','rider') DEFAULT 'customer',
    loyalty_points INT DEFAULT 0,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Staff & rider pre-seeded (password = admin123)
INSERT IGNORE INTO users (name, password, role) VALUES
('Kitchen Staff', 'admin123', 'staff'),
('Ahmad Rider',   'admin123', 'rider');
