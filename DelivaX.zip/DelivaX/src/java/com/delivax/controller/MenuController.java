package com.delivax.controller;

import com.delivax.dao.MenuDAO;
import com.delivax.model.MenuItem;
import com.delivax.util.RoleSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="MenuController", urlPatterns={"/menu"})
public class MenuController extends HttpServlet {

    private final MenuDAO menuDAO = new MenuDAO();

    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");

        // Load menu items — always works, no session needed
        String cat    = req.getParameter("cat");
        String search = req.getParameter("search");

        List<MenuItem> items;
        if (search != null && !search.trim().isEmpty()) {
            items = menuDAO.search(search);
        } else {
            items = menuDAO.getByCategory(cat);
        }

        req.setAttribute("items",      items);
        req.setAttribute("categories", menuDAO.getCategories());
        req.setAttribute("activeCat",  cat    != null ? cat    : "All");
        req.setAttribute("search",     search != null ? search : "");

        // Determine session info — safe null checks
        String sessionUser = null;
        String sessionRole = "guest";

        Map<String,Object> custSession = RoleSession.get(req, "customer");
        if (custSession != null && custSession.get("user") != null) {
            sessionUser = (String) custSession.get("user");
            sessionRole = "customer";
        } else if (RoleSession.isLoggedIn(req, "staff")) {
            sessionRole = "staff";
            Object u = RoleSession.getAttribute(req, "staff", "user");
            if (u != null) sessionUser = u.toString();
        } else if (RoleSession.isLoggedIn(req, "rider")) {
            sessionRole = "rider";
            Object u = RoleSession.getAttribute(req, "rider", "user");
            if (u != null) sessionUser = u.toString();
        }

        req.setAttribute("sessionUser", sessionUser);
        req.setAttribute("sessionRole", sessionRole);

        req.getRequestDispatcher("/WEB-INF/views/menu.jsp").forward(req, res);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }

    @Override
    public String getServletInfo() { return "Menu page"; }
}
