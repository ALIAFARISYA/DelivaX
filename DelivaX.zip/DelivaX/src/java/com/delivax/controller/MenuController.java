package com.delivax.controller;

import com.delivax.dao.MenuDAO;
import com.delivax.model.MenuItem;
import com.delivax.util.RoleSession;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="MenuController", urlPatterns={"/menu"})
public class MenuController extends HttpServlet {

    private final MenuDAO menuDAO = new MenuDAO();

    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");

        // Pass customer session info to JSP via request attributes
        // (menu is viewable by guests and customers)
        String sessionUser = (String) RoleSession.getAttribute(req, "customer", "user");
        String sessionRole = RoleSession.isLoggedIn(req, "customer") ? "customer"
                           : RoleSession.isLoggedIn(req, "staff")    ? "staff"
                           : RoleSession.isLoggedIn(req, "rider")    ? "rider"
                           : "guest";

        req.setAttribute("sessionUser", sessionUser);
        req.setAttribute("sessionRole", sessionRole);

        String cat    = req.getParameter("cat");
        String search = req.getParameter("search");
        List<MenuItem> items;
        if (search != null && !search.trim().isEmpty()) items = menuDAO.search(search);
        else items = menuDAO.getByCategory(cat);

        req.setAttribute("items",      items);
        req.setAttribute("categories", menuDAO.getCategories());
        req.setAttribute("activeCat",  cat    != null ? cat    : "All");
        req.setAttribute("search",     search != null ? search : "");
        req.getRequestDispatcher("/WEB-INF/views/menu.jsp").forward(req, res);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }
    @Override public String getServletInfo() { return "Menu"; }
}
