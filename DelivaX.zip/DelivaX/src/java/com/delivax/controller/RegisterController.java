package com.delivax.controller;

import com.delivax.dao.UserDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="RegisterController", urlPatterns={"/register"})
public class RegisterController extends HttpServlet {

    private final UserDAO dao = new UserDAO();

    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");
        req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, res);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");

        String name     = trim(req, "name");
        String password = trim(req, "password");
        String confirm  = trim(req, "confirm");

        if (name.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
            req.setAttribute("error", "All fields are required."); forward(req, res); return;
        }
        if (name.length() < 3) {
            req.setAttribute("error", "Name must be at least 3 characters."); forward(req, res); return;
        }
        if (password.length() < 6) {
            req.setAttribute("error", "Password must be at least 6 characters."); forward(req, res); return;
        }
        if (!password.equals(confirm)) {
            req.setAttribute("error", "Passwords do not match."); forward(req, res); return;
        }

        boolean exists;
        try {
            exists = dao.nameExists(name);
        } catch (RuntimeException e) {
            req.setAttribute("error", "Database error: " + e.getMessage()
                + " — Make sure MySQL is running and the 'delivax' database exists.");
            forward(req, res); return;
        }

        if (exists) {
            req.setAttribute("error", "This name is already taken. Please choose another name.");
            forward(req, res); return;
        }

        boolean ok;
        try {
            ok = dao.register(name, password);
        } catch (RuntimeException e) {
            req.setAttribute("error", "Database error: " + e.getMessage());
            forward(req, res); return;
        }

        if (!ok) {
            req.setAttribute("error", "Registration failed. Please try again.");
            forward(req, res); return;
        }

        req.getSession(true).setAttribute("regSuccess",
            "Account created successfully! Welcome, " + name + ". Please login below.");
        res.sendRedirect(req.getContextPath() + "/login");
    }

    private void forward(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, res);
    }

    private String trim(HttpServletRequest r, String n) {
        String v = r.getParameter(n); return v != null ? v.trim() : "";
    }

    @Override public String getServletInfo() { return "Customer registration"; }
}
