package com.delivax.controller;

import com.delivax.dao.UserDAO;
import com.delivax.model.User;
import com.delivax.util.RoleSession;
import java.io.IOException;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="LoginController", urlPatterns={"/login"})
public class LoginController extends HttpServlet {

    private final UserDAO dao = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");
        req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html;charset=UTF-8");

        if ("guest".equals(req.getParameter("action"))) {
            res.sendRedirect(req.getContextPath() + "/menu");
            return;
        }

        String name     = trim(req, "name");
        String password = trim(req, "password");
        String role     = trim(req, "role");
        if (role.isEmpty()) role = "customer";

        if (name.isEmpty() || password.isEmpty()) {
            req.setAttribute("error", "Please enter your name and password.");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, res);
            return;
        }

        User user;
        try {
            user = dao.login(name, password, role);
        } catch (RuntimeException e) {
            req.setAttribute("error", "Database error: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, res);
            return;
        }

        if (user == null) {
            req.setAttribute("error", "Incorrect name, password or role.");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, res);
            return;
        }

        // Create a role-specific session (uses its own cookie: DELIVAX_CUSTOMER/STAFF/RIDER)
        // This does NOT affect sessions of other roles on the same browser
        Map<String,Object> session = RoleSession.create(req, res, role);
        session.put("user",       user.getName());
        session.put("userId",     user.getId());
        session.put("role",       user.getRole());
        session.put("loyaltyPts", user.getLoyaltyPoints());

        switch (role) {
            case "staff": res.sendRedirect(req.getContextPath() + "/staff"); break;
            case "rider": res.sendRedirect(req.getContextPath() + "/rider"); break;
            default:      res.sendRedirect(req.getContextPath() + "/menu");
        }
    }

    private String trim(HttpServletRequest r, String n) {
        String v = r.getParameter(n); return v != null ? v.trim() : "";
    }

    @Override public String getServletInfo() { return "Login"; }
}
