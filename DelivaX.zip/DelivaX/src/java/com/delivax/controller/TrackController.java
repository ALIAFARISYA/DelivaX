package com.delivax.controller;

import com.delivax.model.Order;
import com.delivax.util.RoleSession;
import com.delivax.util.SessionGuard;
import java.io.IOException;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="TrackController", urlPatterns={"/track"})
public class TrackController extends HttpServlet {

    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "customer")) return;
        res.setContentType("text/html;charset=UTF-8");
        String id=req.getParameter("id"), confirmed=req.getParameter("confirmed");
        Order order=null;
        if(id!=null&&!id.isEmpty()) order=CheckoutController.getOrderDAO().findById(id);
        req.setAttribute("order",order);
        req.setAttribute("confirmed","true".equals(confirmed));
        req.getRequestDispatcher("/WEB-INF/views/track.jsp").forward(req,res);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req,res); }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req,res); }
    @Override public String getServletInfo(){return "Order tracking";}
}
