package com.delivax.controller;

import com.delivax.util.SessionGuard;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="StaffController", urlPatterns={"/staff"})
public class StaffController extends HttpServlet {

    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "staff")) return;
        res.setContentType("text/html;charset=UTF-8");
        var dao=CheckoutController.getOrderDAO();
        req.setAttribute("activeOrders",  dao.getActiveForStaff());
        req.setAttribute("historyOrders", dao.getHistoryForStaff());
        req.setAttribute("pending",       dao.countByStatus("Pending"));
        req.setAttribute("preparing",     dao.countByStatus("Preparing"));
        req.setAttribute("ready",         dao.countByStatus("Ready"));
        req.getRequestDispatcher("/WEB-INF/views/staff.jsp").forward(req,res);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req,res); }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "staff")) return;
        String oid=req.getParameter("orderId"),status=req.getParameter("status");
        if(oid!=null&&status!=null) CheckoutController.getOrderDAO().updateStatus(oid,status);
        res.sendRedirect(req.getContextPath()+"/staff");
    }
    @Override public String getServletInfo(){return "Kitchen dashboard";}
}
