package com.delivax.controller;

import com.delivax.util.RoleSession;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="LogoutController", urlPatterns={"/logout"})
public class LogoutController extends HttpServlet {

    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        // Only destroy the role specified, or detect from referer
        String role = req.getParameter("role");
        if (role == null || role.isEmpty()) {
            // Destroy all role sessions
            RoleSession.destroy(req, res, "customer");
            RoleSession.destroy(req, res, "staff");
            RoleSession.destroy(req, res, "rider");
        } else {
            RoleSession.destroy(req, res, role);
        }
        res.sendRedirect(req.getContextPath() + "/login");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }
    @Override public String getServletInfo() { return "Logout"; }
}
