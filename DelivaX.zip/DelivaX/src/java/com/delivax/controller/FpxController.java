package com.delivax.controller;

import com.delivax.util.RoleSession;
import com.delivax.util.SessionGuard;
import java.io.IOException;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

/**
 * FpxController — handles FPX bank selection and gateway pages.
 * URL /fpx?step=bank  → bank selection page
 * URL /fpx?step=gate  → payment gateway (TAC entry)
 * URL /fpx?step=done  → payment confirmed, places order
 * URL /fpx?step=cancel → payment cancelled, back to checkout
 */
@WebServlet(name="FpxController", urlPatterns={"/fpx"})
public class FpxController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "customer")) return;
        res.setContentType("text/html;charset=UTF-8");

        String step = req.getParameter("step");
        if (step == null) step = "bank";

        switch (step) {
            case "gate":
                req.getRequestDispatcher("/WEB-INF/views/fpxGateway.jsp").forward(req, res);
                break;
            case "done":
                handlePaymentDone(req, res);
                break;
            case "cancel":
                res.sendRedirect(req.getContextPath() + "/checkout");
                break;
            default:
                req.getRequestDispatcher("/WEB-INF/views/fpxBank.jsp").forward(req, res);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "customer")) return;

        String step = req.getParameter("step");
        if ("bank".equals(step)) {
            // Store selected bank in role session, go to gateway
            String bankCode = req.getParameter("bankCode");
            String bankName = req.getParameter("bankName");
            Map<String,Object> rs = RoleSession.get(req, "customer");
            if (rs != null) {
                rs.put("fpxBank", bankName);
                rs.put("fpxBankCode", bankCode);
            }
            res.sendRedirect(req.getContextPath() + "/fpx?step=gate");
        } else if ("done".equals(step)) {
            handlePaymentDone(req, res);
        }
    }

    @SuppressWarnings("unchecked")
    private void handlePaymentDone(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {
        // Payment confirmed — run same checkout logic as CheckoutController
        // but payment method is already "fpx"
        Map<String,Object> rs = RoleSession.get(req, "customer");
        if (rs == null) { res.sendRedirect(req.getContextPath() + "/login"); return; }

        java.util.Map<Integer, com.delivax.model.CartItem> cart =
            (java.util.Map<Integer, com.delivax.model.CartItem>) rs.get("cart");
        if (cart == null || cart.isEmpty()) {
            res.sendRedirect(req.getContextPath() + "/cart"); return;
        }

        String name    = rs.get("fpxCustomerName")  != null ? (String)rs.get("fpxCustomerName")  : "";
        String phone   = rs.get("fpxCustomerPhone") != null ? (String)rs.get("fpxCustomerPhone") : "";
        String address = rs.get("fpxCustomerAddr")  != null ? (String)rs.get("fpxCustomerAddr")  : "";
        String txnId   = req.getParameter("txnId");
        String bankName= rs.get("fpxBank")          != null ? (String)rs.get("fpxBank")          : "FPX";

        double sub = 0;
        for (com.delivax.model.CartItem c : cart.values()) sub += c.getSubtotal();
        double disc = 0; String dtype = (String)rs.get("discountType");
        Object dobj = rs.get("discount");
        if (dobj instanceof Number) disc = ((Number)dobj).doubleValue();
        double delfee = "delivery".equals(dtype) ? Math.max(0,3.0-disc) : 3.0;
        double voff   = "delivery".equals(dtype) ? 0 : disc;
        double total  = Math.max(0, sub - voff + delfee);

        com.delivax.model.Order order = new com.delivax.model.Order();
        order.setId(CheckoutController.getOrderDAO().nextId());
        order.setItems(new java.util.ArrayList<>(cart.values()));
        order.setStatus("Pending");
        order.setCustomerName(name); order.setCustomerPhone(phone);
        order.setCustomerAddress(address);
        order.setPaymentMethod("FPX - " + bankName);
        order.setTotal(total);
        java.util.Date now = new java.util.Date();
        order.setDate(new java.text.SimpleDateFormat("dd/MM/yyyy").format(now));
        order.setTime(new java.text.SimpleDateFormat("hh:mm a").format(now));
        CheckoutController.getOrderDAO().save(order);

        int pts = (int)(total/2);
        Object uid = rs.get("userId");
        if (uid instanceof Integer) new com.delivax.dao.UserDAO().addLoyalty((Integer)uid, pts);
        int cur = rs.get("loyaltyPts") instanceof Integer ? (Integer)rs.get("loyaltyPts") : 0;
        rs.put("loyaltyPts", cur + pts);
        rs.put("ptsEarned", pts);
        rs.remove("cart"); rs.remove("voucher"); rs.remove("discount");
        rs.remove("discountType"); rs.remove("fpxBank"); rs.remove("fpxBankCode");
        rs.remove("fpxCustomerName"); rs.remove("fpxCustomerPhone"); rs.remove("fpxCustomerAddr");

        res.sendRedirect(req.getContextPath() + "/track?id=" + order.getId() + "&confirmed=true");
    }
}
