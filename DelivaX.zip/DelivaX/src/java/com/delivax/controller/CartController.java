package com.delivax.controller;

import com.delivax.dao.MenuDAO;
import com.delivax.model.Addon;
import com.delivax.model.CartItem;
import com.delivax.model.MenuItem;
import com.delivax.util.RoleSession;
import com.delivax.util.SessionGuard;
import java.io.IOException;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="CartController", urlPatterns={"/cart"})
public class CartController extends HttpServlet {

    private final MenuDAO menuDAO = new MenuDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "customer")) return;
        res.setContentType("text/html;charset=UTF-8");
        req.getRequestDispatcher("/WEB-INF/views/cart.jsp").forward(req, res);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "customer")) return;

        String action = req.getParameter("action");
        Map<String,Object> rsession = RoleSession.get(req, "customer");

        Map<Integer,CartItem> cart = (Map<Integer,CartItem>) rsession.get("cart");
        if (cart == null) { cart = new LinkedHashMap<>(); rsession.put("cart", cart); }

        if ("add".equals(action)) {
            int id = Integer.parseInt(req.getParameter("id"));
            MenuItem m = menuDAO.findById(id);
            if (m != null) {
                List<String> addonNames = new ArrayList<>();
                double addonTotal = 0;
                if (m.getAddons() != null) {
                    for (Addon a : m.getAddons()) {
                        if ("on".equals(req.getParameter("addon_" + a.getId()))) {
                            addonNames.add(a.getName() + " (+RM" + String.format("%.2f",a.getPrice()) + ")");
                            addonTotal += a.getPrice();
                        }
                    }
                }
                double unitPrice = m.getPrice() + addonTotal;
                if (cart.containsKey(id)) cart.get(id).setQty(cart.get(id).getQty()+1);
                else cart.put(id, new CartItem(m.getId(),m.getName(),m.getPrice(),
                    unitPrice,m.getImgUrl(),m.getCategory(),addonNames));
            }
        } else if ("inc".equals(action)) {
            int id=Integer.parseInt(req.getParameter("id"));
            if(cart.containsKey(id)) cart.get(id).setQty(cart.get(id).getQty()+1);
        } else if ("dec".equals(action)) {
            int id=Integer.parseInt(req.getParameter("id"));
            if(cart.containsKey(id)){int q=cart.get(id).getQty()-1;if(q<=0)cart.remove(id);else cart.get(id).setQty(q);}
        } else if ("remove".equals(action)) {
            cart.remove(Integer.parseInt(req.getParameter("id")));
        } else if ("voucher".equals(action)) {
            applyVoucher(rsession, req.getParameter("code"), cart);
            res.sendRedirect(req.getContextPath()+"/cart"); return;
        } else if ("removevoucher".equals(action)) {
            rsession.remove("voucher"); rsession.remove("discount");
            rsession.remove("discountType"); rsession.put("voucherMsg","Voucher removed.");
            res.sendRedirect(req.getContextPath()+"/cart"); return;
        }
        String from = req.getParameter("from");
        if ("menu".equals(from)) res.sendRedirect(req.getContextPath()+"/menu");
        else res.sendRedirect(req.getContextPath()+"/cart");
    }

    private void applyVoucher(Map<String,Object> s, String code, Map<Integer,CartItem> cart) {
        double sub=0; for(CartItem c:cart.values()) sub+=c.getSubtotal();
        if(code==null){s.put("voucherMsg","❌ Invalid code.");return;}
        switch(code.trim().toUpperCase()){
            case"WELCOME10": if(sub>=20){s.put("voucher","WELCOME10");s.put("discount",sub*0.10);s.put("discountType","pct");s.put("voucherMsg","✅ 10% off applied!");}else s.put("voucherMsg","❌ Min order RM20.");break;
            case"SAVE15":    if(sub>=30){s.put("voucher","SAVE15");s.put("discount",sub*0.15);s.put("discountType","pct");s.put("voucherMsg","✅ 15% off applied!");}else s.put("voucherMsg","❌ Min order RM30.");break;
            case"FLAT8":     if(sub>=25){s.put("voucher","FLAT8");s.put("discount",8.0);s.put("discountType","fixed");s.put("voucherMsg","✅ RM8 off applied!");}else s.put("voucherMsg","❌ Min order RM25.");break;
            case"FREEDEL":   if(sub>=40){s.put("voucher","FREEDEL");s.put("discount",3.0);s.put("discountType","delivery");s.put("voucherMsg","✅ Free delivery applied!");}else s.put("voucherMsg","❌ Min order RM40.");break;
            default: s.put("voucherMsg","❌ Invalid voucher code.");
        }
    }
    @Override public String getServletInfo(){return "Cart";}
}
