package com.delivax.controller;

import com.delivax.dao.OrderDAO;
import com.delivax.dao.UserDAO;
import com.delivax.model.CartItem;
import com.delivax.model.Order;
import com.delivax.util.RoleSession;
import com.delivax.util.SessionGuard;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="CheckoutController", urlPatterns={"/checkout"})
public class CheckoutController extends HttpServlet {

    private static final OrderDAO orderDAO = new OrderDAO();
    private static final UserDAO  userDAO  = new UserDAO();
    private static final double   DELIVERY = 3.0;

    public static OrderDAO getOrderDAO(){ return orderDAO; }

    @Override
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "customer")) return;
        Map<String,Object> rs = RoleSession.get(req, "customer");
        Map<Integer,CartItem> cart = (Map<Integer,CartItem>) rs.get("cart");
        if(cart==null||cart.isEmpty()){res.sendRedirect(req.getContextPath()+"/cart");return;}
        res.setContentType("text/html;charset=UTF-8");
        req.getRequestDispatcher("/WEB-INF/views/checkout.jsp").forward(req, res);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "customer")) return;
        Map<String,Object> rs = RoleSession.get(req, "customer");
        Map<Integer,CartItem> cart=(Map<Integer,CartItem>)rs.get("cart");
        if(cart==null||cart.isEmpty()){res.sendRedirect(req.getContextPath()+"/cart");return;}

        String name=p(req,"name"),phone=p(req,"phone"),address=p(req,"address"),payment=p(req,"payment");
        if(payment.isEmpty()) payment="cod";

        if(name.isEmpty()||phone.isEmpty()||address.isEmpty()){
            rs.put("checkoutErr","Please fill in Name, Phone and Address.");
            res.sendRedirect(req.getContextPath()+"/checkout");return;
        }

        // If FPX selected → save delivery details in session, redirect to FPX bank selection
        if("fpx".equals(payment)){
            rs.put("fpxCustomerName",  name);
            rs.put("fpxCustomerPhone", phone);
            rs.put("fpxCustomerAddr",  address);
            res.sendRedirect(req.getContextPath()+"/fpx?step=bank");
            return;
        }

        // Card or COD — place order directly
        double sub=0; for(CartItem c:cart.values()) sub+=c.getSubtotal();
        double disc=0; String dtype=(String)rs.get("discountType");
        Object dobj=rs.get("discount");
        if(dobj instanceof Number) disc=((Number)dobj).doubleValue();
        double delfee="delivery".equals(dtype)?Math.max(0,DELIVERY-disc):DELIVERY;
        double voff="delivery".equals(dtype)?0:disc;
        double total=Math.max(0,sub-voff+delfee);

        Order order=new Order();
        order.setId(orderDAO.nextId());
        order.setItems(new ArrayList<>(cart.values()));
        order.setStatus("Pending");
        order.setCustomerName(name); order.setCustomerPhone(phone);
        order.setCustomerAddress(address); order.setPaymentMethod(payment);
        order.setTotal(total);
        Date now=new Date();
        order.setDate(new SimpleDateFormat("dd/MM/yyyy").format(now));
        order.setTime(new SimpleDateFormat("hh:mm a").format(now));
        orderDAO.save(order);

        int pts=(int)(total/2);
        Object uid=rs.get("userId");
        if(uid instanceof Integer) userDAO.addLoyalty((Integer)uid,pts);
        int cur=rs.get("loyaltyPts") instanceof Integer?(Integer)rs.get("loyaltyPts"):0;
        rs.put("loyaltyPts",cur+pts); rs.put("ptsEarned",pts);
        rs.remove("cart"); rs.remove("voucher");
        rs.remove("discount"); rs.remove("discountType"); rs.remove("checkoutErr");
        res.sendRedirect(req.getContextPath()+"/track?id="+order.getId()+"&confirmed=true");
    }

    private String p(HttpServletRequest r,String n){String v=r.getParameter(n);return v!=null?v.trim():"";}
    @Override public String getServletInfo(){return "Checkout";}
}
