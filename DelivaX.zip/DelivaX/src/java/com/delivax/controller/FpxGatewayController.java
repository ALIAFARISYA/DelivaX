package com.delivax.controller;

import com.delivax.util.SessionGuard;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="FpxGatewayController", urlPatterns={"/fpxGateway"})
public class FpxGatewayController extends HttpServlet {

    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "customer")) return;
        res.setContentType("text/html;charset=UTF-8");
        req.getRequestDispatcher("/WEB-INF/views/fpxGateway.jsp").forward(req, res);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req, res); }
    @Override public String getServletInfo() { return "FPX Payment Gateway"; }
}
