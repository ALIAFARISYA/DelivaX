package com.delivax.controller;

import com.delivax.util.RoleSession;
import com.delivax.util.SessionGuard;
import java.io.IOException;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet(name="RiderController", urlPatterns={"/rider"})
public class RiderController extends HttpServlet {

    private static final double EARN=3.0;

    protected void processRequest(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "rider")) return;
        res.setContentType("text/html;charset=UTF-8");
        var dao=CheckoutController.getOrderDAO();
        req.setAttribute("activeOrders",  dao.getActiveForRider());
        req.setAttribute("historyOrders", dao.getHistoryForRider());
        req.setAttribute("toPickup",      dao.countByStatus("Ready"));
        req.setAttribute("delivering",    dao.countByStatus("Delivering"));
        req.setAttribute("delivered",     dao.countByStatus("Delivered"));
        req.getRequestDispatcher("/WEB-INF/views/rider.jsp").forward(req,res);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException { processRequest(req,res); }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!SessionGuard.check(req, res, "rider")) return;
        Map<String,Object> rs = RoleSession.get(req, "rider");
        String oid=req.getParameter("orderId"),status=req.getParameter("status");
        if(oid!=null&&status!=null){
            CheckoutController.getOrderDAO().updateStatus(oid,status);
            if("Delivered".equals(status)&&rs!=null){
                int d=rs.get("riderDeliveries") instanceof Integer?(Integer)rs.get("riderDeliveries"):0;
                double e=rs.get("riderEarnings") instanceof Double?(Double)rs.get("riderEarnings"):0.0;
                rs.put("riderDeliveries",d+1);
                rs.put("riderEarnings",e+EARN);
            }
        }
        res.sendRedirect(req.getContextPath()+"/rider");
    }
    @Override public String getServletInfo(){return "Rider dashboard";}
}
