package com.delivax.util;

import jakarta.servlet.http.HttpSession;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SessionRegistry — ensures only ONE active session per account (name + role).
 *
 * Scenario: Same account "Ahmad" logs in as customer on Phone AND Laptop.
 *   → The Laptop login kicks out the Phone session (or vice versa).
 *
 * Scenario: "Ahmad" (customer, Phone) and "Siti" (customer, Laptop).
 *   → Both work perfectly — different accounts, different registry slots.
 *
 * Scenario: "Kitchen Staff" (staff, Kitchen PC) and "Ahmad Rider" (rider, Phone).
 *   → Both work perfectly — different names and roles.
 *
 * Scenario: Same browser, same device — logs in as customer then as staff.
 *   → Same HttpSession just changes role. No cross-device conflict.
 *   → SessionRegistry tracks name::role separately so no collision.
 */
public class SessionRegistry {

    private static final Map<String, String> SESSION_IDS = new ConcurrentHashMap<>();
    private static final Map<String, HttpSession> SESSIONS = new ConcurrentHashMap<>();

    public static void register(String name, String role, HttpSession newSession) {
        String key = name + "::" + role;
        String newId = newSession.getId();

        HttpSession old = SESSIONS.get(key);
        if (old != null && !old.getId().equals(newId)) {
            // Same account logged in on another device — kick the old session
            try {
                old.setAttribute("kickedOut", true);
                old.invalidate();
            } catch (IllegalStateException e) {
                // Already gone
            }
        }

        SESSIONS.put(key, newSession);
        SESSION_IDS.put(key, newId);
    }

    public static void deregister(String name, String role, String sessionId) {
        String key = name + "::" + role;
        String registered = SESSION_IDS.get(key);
        if (sessionId.equals(registered)) {
            SESSIONS.remove(key);
            SESSION_IDS.remove(key);
        }
    }

    public static boolean isActive(String name, String role, String sessionId) {
        String registered = SESSION_IDS.get(name + "::" + role);
        return sessionId.equals(registered);
    }
}
