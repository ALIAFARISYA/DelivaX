package com.delivax.util;
import java.sql.*;

public class DBConnection {
    private static final String URL  = "jdbc:mysql://localhost:3306/delivax?useSSL=false&serverTimezone=Asia/Kuala_Lumpur&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASS = "admin";  // change if you have MySQL password

    public static Connection getConnection() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch(ClassNotFoundException e){ throw new SQLException("MySQL driver missing",e); }
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
