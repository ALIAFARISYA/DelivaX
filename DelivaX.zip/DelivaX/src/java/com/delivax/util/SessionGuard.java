package com.delivax.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * SessionGuard — checks role-specific session cookie.
 * Each role has its own independent cookie so they don't interfere.
 */
public class SessionGuard {

    public static boolean check(HttpServletRequest req,
                                HttpServletResponse res,
                                String requiredRole) throws IOException {
        if (!RoleSession.isLoggedIn(req, requiredRole)) {
            res.sendRedirect(req.getContextPath() + "/login");
            return false;
        }
        return true;
    }
}
