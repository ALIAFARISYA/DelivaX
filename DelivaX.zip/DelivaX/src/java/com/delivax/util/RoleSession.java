package com.delivax.util;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RoleSession — gives each role its own independent session.
 *
 * How it works:
 *   - Customer  uses cookie: DELIVAX_CUSTOMER
 *   - Staff     uses cookie: DELIVAX_STAFF
 *   - Rider     uses cookie: DELIVAX_RIDER
 *
 * Each cookie holds a session token (UUID).
 * Session data is stored in a server-side map keyed by that token.
 *
 * This means all 3 roles can be active simultaneously on the same browser
 * because they use different cookies — Tomcat's JSESSIONID is NOT used for auth.
 */
public class RoleSession {

    // Server-side session store: token -> data map
    private static final ConcurrentHashMap<String, Map<String,Object>>
        STORE = new ConcurrentHashMap<>();

    private static final String COOKIE_PREFIX = "DELIVAX_";
    private static final int    MAX_AGE       = 60 * 60; // 1 hour

    /** Get cookie name for a role */
    public static String cookieName(String role) {
        return COOKIE_PREFIX + role.toUpperCase();
    }

    /** Read the session token from the role-specific cookie */
    public static String getToken(HttpServletRequest req, String role) {
        if (req.getCookies() == null) return null;
        String name = cookieName(role);
        for (Cookie c : req.getCookies()) {
            if (name.equals(c.getName())) return c.getValue();
        }
        return null;
    }

    /** Create a new session for a role, set the cookie, return session map */
    public static Map<String,Object> create(HttpServletRequest req,
                                             HttpServletResponse res,
                                             String role) {
        // Invalidate old token if exists
        String old = getToken(req, role);
        if (old != null) STORE.remove(old);

        String token = java.util.UUID.randomUUID().toString();
        Map<String,Object> data = new ConcurrentHashMap<>();
        STORE.put(token, data);

        Cookie c = new Cookie(cookieName(role), token);
        c.setPath("/");
        c.setMaxAge(MAX_AGE);
        c.setHttpOnly(true);
        res.addCookie(c);
        return data;
    }

    /** Get existing session data for a role (null if not logged in) */
    public static Map<String,Object> get(HttpServletRequest req, String role) {
        String token = getToken(req, role);
        if (token == null) return null;
        return STORE.get(token);
    }

    /** Destroy the session for a role (logout) */
    public static void destroy(HttpServletRequest req,
                                HttpServletResponse res,
                                String role) {
        String token = getToken(req, role);
        if (token != null) STORE.remove(token);
        Cookie c = new Cookie(cookieName(role), "");
        c.setPath("/");
        c.setMaxAge(0);
        res.addCookie(c);
    }

    /** Check if logged in for a role */
    public static boolean isLoggedIn(HttpServletRequest req, String role) {
        return get(req, role) != null;
    }

    /** Get a specific attribute from role session */
    public static Object getAttribute(HttpServletRequest req, String role, String key) {
        Map<String,Object> data = get(req, role);
        return data != null ? data.get(key) : null;
    }

    /** Set a specific attribute in role session */
    public static void setAttribute(HttpServletRequest req, String role,
                                     String key, Object value) {
        Map<String,Object> data = get(req, role);
        if (data != null) data.put(key, value);
    }

    /** Remove a specific attribute from role session */
    public static void removeAttribute(HttpServletRequest req, String role, String key) {
        Map<String,Object> data = get(req, role);
        if (data != null) data.remove(key);
    }
}
