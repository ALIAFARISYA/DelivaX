package com.delivax.model;

import java.util.List;

public class MenuItem {
    private int    id;
    private String name;
    private String category;
    private double price;
    private boolean deal;
    private String imgUrl;
    private String desc;
    private List<Addon> addons;

    public MenuItem(int id, String name, String category, double price, boolean deal,
                    String imgUrl, String desc, List<Addon> addons) {
        this.id=id; this.name=name; this.category=category; this.price=price;
        this.deal=deal; this.imgUrl=imgUrl; this.desc=desc; this.addons=addons;
    }

    public int    getId()         { return id; }
    public String getName()       { return name; }
    public String getCategory()   { return category; }
    public double getPrice()      { return price; }
    public boolean isDeal()       { return deal; }
    public String getImgUrl()     { return imgUrl; }
    public String getDesc()       { return desc; }
    public List<Addon> getAddons(){ return addons; }
}
