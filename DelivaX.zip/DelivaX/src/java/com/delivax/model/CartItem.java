package com.delivax.model;

import java.io.Serializable;
import java.util.List;

public class CartItem implements Serializable {
    private int    id;
    private String name;
    private double price;      // base price
    private double unitPrice;  // base + addons
    private int    qty;
    private String imgUrl;
    private String category;
    private List<String> selectedAddons; // addon names for display

    public CartItem() {}
    public CartItem(int id, String name, double price, double unitPrice, String imgUrl,
                    String category, List<String> selectedAddons) {
        this.id=id; this.name=name; this.price=price; this.unitPrice=unitPrice;
        this.imgUrl=imgUrl; this.category=category; this.selectedAddons=selectedAddons; this.qty=1;
    }

    public int    getId()                   { return id; }
    public void   setId(int id)             { this.id=id; }
    public String getName()                 { return name; }
    public void   setName(String n)         { this.name=n; }
    public double getPrice()                { return price; }
    public void   setPrice(double p)        { this.price=p; }
    public double getUnitPrice()            { return unitPrice; }
    public void   setUnitPrice(double p)    { this.unitPrice=p; }
    public int    getQty()                  { return qty; }
    public void   setQty(int q)             { this.qty=q; }
    public String getImgUrl()               { return imgUrl; }
    public void   setImgUrl(String u)       { this.imgUrl=u; }
    public String getCategory()             { return category; }
    public void   setCategory(String c)     { this.category=c; }
    public List<String> getSelectedAddons() { return selectedAddons; }
    public void   setSelectedAddons(List<String> a){ this.selectedAddons=a; }
    public double getSubtotal()             { return unitPrice * qty; }

    public String getAddonsDisplay() {
        if (selectedAddons == null || selectedAddons.isEmpty()) return "";
        return String.join(", ", selectedAddons);
    }
}
