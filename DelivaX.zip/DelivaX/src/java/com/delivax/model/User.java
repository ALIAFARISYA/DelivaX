package com.delivax.model;
import java.io.Serializable;

public class User implements Serializable {
    private int    id;
    private String name;
    private String password;
    private String role;
    private int    loyaltyPoints;

    public User(){}
    public int    getId()               { return id; }
    public void   setId(int id)         { this.id=id; }
    public String getName()             { return name; }
    public void   setName(String n)     { this.name=n; }
    public String getPassword()         { return password; }
    public void   setPassword(String p) { this.password=p; }
    public String getRole()             { return role; }
    public void   setRole(String r)     { this.role=r; }
    public int    getLoyaltyPoints()    { return loyaltyPoints; }
    public void   setLoyaltyPoints(int p){ this.loyaltyPoints=p; }
    public String getTier(){
        if(loyaltyPoints>=1000) return "Platinum";
        if(loyaltyPoints>=500)  return "Gold";
        return "Silver";
    }
}
