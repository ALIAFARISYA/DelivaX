package com.delivax.model;

import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {
    private String id;
    private List<CartItem> items;
    private String status; // Pending, Preparing, Ready, Delivering, Delivered, Cancelled
    private String customerName;
    private String customerPhone;
    private String customerAddress;
    private String paymentMethod;
    private double total;
    private String date;
    private String time;

    public Order() {}

    public String getId()                       { return id; }
    public void   setId(String id)              { this.id = id; }
    public List<CartItem> getItems()            { return items; }
    public void   setItems(List<CartItem> i)    { this.items = i; }
    public String getStatus()                   { return status; }
    public void   setStatus(String s)           { this.status = s; }
    public String getCustomerName()             { return customerName; }
    public void   setCustomerName(String n)     { this.customerName = n; }
    public String getCustomerPhone()            { return customerPhone; }
    public void   setCustomerPhone(String p)    { this.customerPhone = p; }
    public String getCustomerAddress()          { return customerAddress; }
    public void   setCustomerAddress(String a)  { this.customerAddress = a; }
    public String getPaymentMethod()            { return paymentMethod; }
    public void   setPaymentMethod(String m)    { this.paymentMethod = m; }
    public double getTotal()                    { return total; }
    public void   setTotal(double t)            { this.total = t; }
    public String getDate()                     { return date; }
    public void   setDate(String d)             { this.date = d; }
    public String getTime()                     { return time; }
    public void   setTime(String t)             { this.time = t; }

    public String getItemsSummary() {
        if (items == null) return "";
        StringBuilder sb = new StringBuilder();
        for (CartItem c : items) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(c.getName()).append(" x").append(c.getQty());
        }
        return sb.toString();
    }

    public String getBadgeClass() {
        if (status == null) return "";
        switch (status) {
            case "Pending":    return "badge-pending";
            case "Preparing":  return "badge-preparing";
            case "Ready":      return "badge-ready";
            case "Delivering": return "badge-delivering";
            case "Delivered":  return "badge-delivered";
            case "Cancelled":  return "badge-cancelled";
            default:           return "";
        }
    }
}
