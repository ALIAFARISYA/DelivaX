package com.delivax.dao;

import com.delivax.model.Order;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class OrderDAO {

    private static final List<Order> ORDERS  = Collections.synchronizedList(new ArrayList<>());
    private static final AtomicInteger COUNTER = new AtomicInteger(1);

    public String nextId() { return "ORD" + String.format("%04d", COUNTER.getAndIncrement()); }

    public void save(Order o) { ORDERS.add(o); }

    public Order findById(String id) {
        for (Order o:ORDERS) if (o.getId().equals(id)) return o;
        return null;
    }

    // Active orders for staff: Pending, Preparing
    public List<Order> getActiveForStaff() {
        List<Order> r=new ArrayList<>();
        for (Order o:ORDERS) if ("Pending".equals(o.getStatus())||"Preparing".equals(o.getStatus())) r.add(o);
        return r;
    }

    // History for staff: Ready, Delivered, Cancelled
    public List<Order> getHistoryForStaff() {
        List<Order> r=new ArrayList<>();
        for (Order o:ORDERS) if ("Ready".equals(o.getStatus())||"Delivered".equals(o.getStatus())||"Cancelled".equals(o.getStatus())) r.add(o);
        Collections.reverse(r); return r;
    }

    // Active for rider: Ready, Delivering
    public List<Order> getActiveForRider() {
        List<Order> r=new ArrayList<>();
        for (Order o:ORDERS) if ("Ready".equals(o.getStatus())||"Delivering".equals(o.getStatus())) r.add(o);
        return r;
    }

    // History for rider: Delivered
    public List<Order> getHistoryForRider() {
        List<Order> r=new ArrayList<>();
        for (Order o:ORDERS) if ("Delivered".equals(o.getStatus())) r.add(o);
        Collections.reverse(r); return r;
    }

    public List<Order> getByStatus(String... statuses) {
        Set<String> set=new HashSet<>(Arrays.asList(statuses));
        List<Order> r=new ArrayList<>();
        for (Order o:ORDERS) if (set.contains(o.getStatus())) r.add(o);
        return r;
    }

    public boolean updateStatus(String id, String status) {
        for (Order o:ORDERS) if (o.getId().equals(id)){o.setStatus(status);return true;}
        return false;
    }

    public long countByStatus(String status) {
        long c=0; for (Order o:ORDERS) if (status.equals(o.getStatus())) c++; return c;
    }
}
