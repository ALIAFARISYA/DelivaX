package com.delivax.dao;

import com.delivax.model.Addon;
import com.delivax.model.MenuItem;
import java.util.*;

public class MenuDAO {

    private static final List<MenuItem> ITEMS = new ArrayList<>();

    static {
        ITEMS.add(new MenuItem(1,"Chicken Mandi","Rice",18.00,true,
            "https://tse3.mm.bing.net/th/id/OIP.q74X3Bh5Szt7A32JBUwYMAHaI7?rs=1&pid=ImgDetMain&o=7&rm=3",
            "Slow-cooked chicken on Yemeni spiced basmati rice.",
            Arrays.asList(new Addon("a1","Extra Chicken Leg",6.00),new Addon("a2","Double Rice",3.00),new Addon("a3","Mandi Sauce",1.00),new Addon("a4","Side Salad",4.00))));
        ITEMS.add(new MenuItem(2,"Lamb Kabsa","Rice",20.00,false,
            "https://tse1.mm.bing.net/th/id/OIP.Oros-9RzKK_yAcl02vIXaQHaHa?rs=1&pid=ImgDetMain&o=7&rm=3",
            "Tender lamb on kabsa rice with raisins & almonds.",
            Arrays.asList(new Addon("b1","Extra Lamb Ribs",9.00),new Addon("b2","Garlic Bread",2.00),new Addon("b3","Extra Sauce",1.00))));
        ITEMS.add(new MenuItem(3,"Shawarma Plate","Grill",14.00,true,
            "https://img.freepik.com/premium-photo/arabic-chicken-shawarma-plate-with-fries-served-dish-isolated-table-side-view-middle-east-food_689047-3434.jpg?w=2000",
            "Marinated meat wrap with garlic sauce & pickles.",
            Arrays.asList(new Addon("c1","Add Cheese",2.00),new Addon("c2","Double Meat",5.00),new Addon("c3","Jalapeños",1.00))));
        ITEMS.add(new MenuItem(4,"Falafel Set","Sides",10.00,false,
            "https://tse3.mm.bing.net/th/id/OIP.MQKc1JLgnorQ1TedF3TNMgHaE7?rs=1&pid=ImgDetMain&o=7&rm=3",
            "Crispy chickpea falafel with hummus & pita bread.",
            Arrays.asList(new Addon("d1","Extra Pita",1.50),new Addon("d2","Extra Hummus",2.00))));
        ITEMS.add(new MenuItem(5,"Arabian Mixed Grill","Grill",19.00,false,
            "https://tse1.mm.bing.net/th/id/OIP.K_G2tw0_dyTb2r_3kTaSggHaD2?rs=1&pid=ImgDetMain&o=7&rm=3",
            "Kofta, kebab & grilled chicken platter with flatbread.",
            Arrays.asList(new Addon("e1","Extra Kofta",5.00),new Addon("e2","Grilled Corn",3.00))));
        ITEMS.add(new MenuItem(6,"Chicken Kebab Rice","Rice",15.00,false,
            "https://tse2.mm.bing.net/th/id/OIP.MQYEgMVs3RUJUXZ0rcqFFQAAAA?rs=1&pid=ImgDetMain&o=7&rm=3",
            "Spiced kebab skewer on basmati with grilled tomato.",
            Arrays.asList(new Addon("f1","Extra Skewer",6.00),new Addon("f2","Fried Egg",1.50))));
        ITEMS.add(new MenuItem(7,"Hummus Bread Set","Sides",11.00,false,
            "https://thumbs.dreamstime.com/b/various-hummus-set-appetizer-flat-bread-side-view-various-hummus-set-appetizer-flat-bread-274275582.jpg",
            "Creamy hummus with olive oil & warm Arabic bread.",
            Arrays.asList(new Addon("g1","Extra Bread",1.50),new Addon("g2","Olives & Pickles",2.50))));
        ITEMS.add(new MenuItem(8,"Arabic Biryani","Rice",17.00,false,
            "https://i.ytimg.com/vi/hjnMhDNVIBE/maxresdefault.jpg",
            "Aromatic saffron rice with fried onions & tender meat.",
            Arrays.asList(new Addon("h1","Extra Meat",7.00),new Addon("h2","Raita Yoghurt",2.00))));
        ITEMS.add(new MenuItem(9,"Mint Tea","Drinks",3.00,true,
            "https://tse2.mm.bing.net/th/id/OIP.sLrdeSOkf6GOlRsz8hoNmgHaHa?rs=1&pid=ImgDetMain&o=7&rm=3",
            "Fresh spearmint brewed with a hint of honey.",
            Arrays.asList(new Addon("i1","Extra Honey",0.50),new Addon("i2","Lemon Wedge",0.50))));
        ITEMS.add(new MenuItem(10,"Arabic Coffee","Drinks",5.00,true,
            "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400",
            "Qahwa with cardamom, saffron & dates on the side.",
            Arrays.asList(new Addon("j1","Dates (3pcs)",2.00))));
        ITEMS.add(new MenuItem(11,"Mango Juice","Drinks",6.00,false,
            "https://tse3.mm.bing.net/th/id/OIP.ZQ2cuRCmRiPLzsdluJyL8QHaHa?rs=1&pid=ImgDetMain&o=7&rm=3",
            "Blended fresh mango, lightly sweetened, ice-cold.",
            Arrays.asList(new Addon("k1","Mango Float",3.00))));
        ITEMS.add(new MenuItem(12,"Soft Drink","Drinks",2.00,false,
            "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400",
            "Cola, lemon or orange — ice cold.",
            Collections.emptyList()));
    }

    public List<MenuItem> getAll()               { return ITEMS; }
    public List<String>   getCategories()        { return Arrays.asList("All","Rice","Grill","Sides","Drinks"); }

    public List<MenuItem> getByCategory(String cat) {
        if (cat==null||"All".equals(cat)) return ITEMS;
        List<MenuItem> r=new ArrayList<>();
        for (MenuItem m:ITEMS) if (m.getCategory().equals(cat)) r.add(m);
        return r;
    }

    public List<MenuItem> search(String q) {
        if (q==null||q.trim().isEmpty()) return ITEMS;
        List<MenuItem> r=new ArrayList<>(); String lo=q.toLowerCase();
        for (MenuItem m:ITEMS) if (m.getName().toLowerCase().contains(lo)) r.add(m);
        return r;
    }

    public MenuItem findById(int id) {
        for (MenuItem m:ITEMS) if (m.getId()==id) return m;
        return null;
    }
}
