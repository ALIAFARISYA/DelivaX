package com.delivax.dao;

import com.delivax.model.User;
import com.delivax.util.DBConnection;
import java.sql.*;

public class UserDAO {

    /** Returns null if wrong credentials, throws RuntimeException if DB fails */
    public User login(String name, String password, String role) {
        String sql = "SELECT * FROM users WHERE name=? AND password=? AND role=? LIMIT 1";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, password);
            ps.setString(3, role);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
            return null; // wrong credentials
        } catch (SQLException e) {
            throw new RuntimeException("DB error during login: " + e.getMessage(), e);
        }
    }

    public boolean nameExists(String name) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT id FROM users WHERE name=? AND role='customer' LIMIT 1")) {
            ps.setString(1, name);
            return ps.executeQuery().next();
        } catch (SQLException e) {
            throw new RuntimeException("DB error checking name: " + e.getMessage(), e);
        }
    }

    public boolean register(String name, String password) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO users(name,password,role,loyalty_points) VALUES(?,?,'customer',0)")) {
            ps.setString(1, name);
            ps.setString(2, password);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("DB error during register: " + e.getMessage(), e);
        }
    }

    public void addLoyalty(int userId, int pts) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "UPDATE users SET loyalty_points=loyalty_points+? WHERE id=?")) {
            ps.setInt(1, pts); ps.setInt(2, userId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // non-critical, don't crash
        }
    }

    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setName(rs.getString("name"));
        u.setPassword(rs.getString("password"));
        u.setRole(rs.getString("role"));
        u.setLoyaltyPoints(rs.getInt("loyalty_points"));
        return u;
    }
}
